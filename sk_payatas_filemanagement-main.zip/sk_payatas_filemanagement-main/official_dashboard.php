<?php
require 'includes/config.php';

// ✅ Restrict access
if (!isset($_SESSION['user_id'])) {
    header('Location: official_login.php');
    exit;
}
if (strtolower($_SESSION['role']) !== 'official') {
    header('Location: admin_dashboard.php');
    exit;
}

// Force officials who must change password into the change-password screen
$check = $mysqli->prepare("SELECT must_change_password FROM users WHERE id = ? LIMIT 1");
if ($check) {
    $uid = (int)$_SESSION['user_id'];
    $check->bind_param("i", $uid);
    $check->execute();
    $row = $check->get_result()->fetch_assoc();
    if ((int)($row['must_change_password'] ?? 0) === 1) {
        header('Location: official_change_password.php');
        exit;
    }
    $check->close();
}

$chkDel = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'deleted_at'");
$hasDel = $chkDel && $chkDel->num_rows > 0;
if ($chkDel) {
    $chkDel->free();
}
$delSql = $hasDel ? " WHERE deleted_at IS NULL" : "";
$delAnd = $hasDel ? " AND deleted_at IS NULL" : "";

// --- Get total files ---
$totalFilesQuery = $mysqli->query("SELECT COUNT(*) AS total FROM files" . $delSql);
$totalFiles = (int)($totalFilesQuery->fetch_assoc()['total'] ?? 0);

$statusCounts = ['Approved'=>0,'Pending'=>0,'Rejected'=>0];
$statusWhere = $hasDel ? " WHERE deleted_at IS NULL" : "";
$sc = $mysqli->query("SELECT status, COUNT(*) AS c FROM files" . $statusWhere . " GROUP BY status");
if ($sc) {
    while ($row = $sc->fetch_assoc()) {
        $s = ucfirst(strtolower(trim($row['status'] ?? '')));
        if ($s === 'Approved') $statusCounts['Approved'] = (int)$row['c'];
        elseif ($s === 'Rejected') $statusCounts['Rejected'] = (int)$row['c'];
        else $statusCounts['Pending'] += (int)$row['c'];
    }
}

// --- Recent Files ---
$recentFiles = $mysqli->query(
    "SELECT id, filename, filepath, size, uploaded_at FROM files" . ($hasDel ? " WHERE deleted_at IS NULL" : "") . " ORDER BY uploaded_at DESC LIMIT 5"
);

// --- Recent Activity ---
$recentActivity = $mysqli->query(
    "SELECT COUNT(*) AS total FROM files WHERE DATE(uploaded_at)=CURDATE()" . ($hasDel ? " AND deleted_at IS NULL" : "")
);
$activityCount = (int)($recentActivity->fetch_assoc()['total'] ?? 0);

// --- Get file counts for categories ---
$documentsCount = (int)($mysqli->query("SELECT COUNT(*) AS total FROM files WHERE category = 'Documents'" . $delAnd)->fetch_assoc()['total'] ?? 0);
$reportsCount = (int)($mysqli->query("SELECT COUNT(*) AS total FROM files WHERE category = 'Reports'" . $delAnd)->fetch_assoc()['total'] ?? 0);
$projectsCount = (int)($mysqli->query("SELECT COUNT(*) AS total FROM files WHERE category = 'Projects'" . $delAnd)->fetch_assoc()['total'] ?? 0);

$pct = static function (int $part, int $whole): float {
    if ($whole <= 0) {
        return 0.0;
    }
    return round(($part / $whole) * 100, 1);
};
$docPct = $pct($documentsCount, $totalFiles);
$repPct = $pct($reportsCount, $totalFiles);
$prjPct = $pct($projectsCount, $totalFiles);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Official Dashboard | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body {
    background-image: url('SK.png');
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
}
.od-card-box {
    background: rgba(255, 255, 255, 0.96);
    border-radius: 14px;
    padding: 1.35rem;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.8);
}
.file-list .file-item {
    background: #f8f9fc;
    padding: 14px 16px;
    border-radius: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    border: 1px solid #eef0f4;
    gap: 0.75rem;
    flex-wrap: wrap;
}
.file-list .file-item:last-child { margin-bottom: 0; }
.storage-bar {
    background: #e9ecef;
    height: 10px;
    border-radius: 999px;
    overflow: hidden;
}
.storage-fill {
    height: 10px;
    background: linear-gradient(90deg, #a902ca, #e599f7);
    transition: width 0.3s ease;
    border-radius: 999px;
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<?php include 'includes/nav_official.php'; ?>

<!-- MAIN -->
<div class="main">
    <div class="dash-topbar">
        <div class="flex-grow-1">
            <h3 class="fw-bold mb-1">Dashboard</h3>
            <p class="text-muted mb-0">Welcome back, <?= htmlspecialchars($_SESSION['fullname']) ?>!</p>
        </div>
        <div class="d-flex align-items-stretch align-items-sm-center gap-2 flex-wrap flex-grow-1 justify-content-sm-end">
            <div class="dash-search-bar flex-grow-1">
                <i class="fa fa-search text-muted"></i>
                <input type="search" id="searchInput" class="form-control form-control-sm" placeholder="Filter recent files…" autocomplete="off">
            </div>
            <a href="upload_file.php" class="btn btn-primary btn-upload-purple text-nowrap"><i class="fa fa-upload me-1"></i> Upload</a>
        </div>
    </div>

    <!-- STATS -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-3">
            <a href="documents.php" class="text-decoration-none text-dark">
                <div class="summary-card summary-doc text-center">
                    <div class="d-flex justify-content-center mb-2"><i class="fa fa-file-lines card-icon"></i></div>
                    <h6 class="fw-semibold mb-2">Documents</h6>
                    <div class="progress mb-2">
                        <div class="progress-bar" role="progressbar" style="width: <?= $docPct ?>%;" aria-valuenow="<?= $docPct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="small text-muted mb-0"><?= $documentsCount ?> file<?= $documentsCount === 1 ? '' : 's' ?></p>
                </div>
            </a>
        </div>
        <div class="col-6 col-xl-3">
            <a href="reports.php" class="text-decoration-none text-dark">
                <div class="summary-card summary-rep text-center">
                    <div class="d-flex justify-content-center mb-2"><i class="fa fa-chart-column card-icon"></i></div>
                    <h6 class="fw-semibold mb-2">Reports</h6>
                    <div class="progress mb-2">
                        <div class="progress-bar" role="progressbar" style="width: <?= $repPct ?>%;" aria-valuenow="<?= $repPct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="small text-muted mb-0"><?= $reportsCount ?> file<?= $reportsCount === 1 ? '' : 's' ?></p>
                </div>
            </a>
        </div>
        <div class="col-6 col-xl-3">
            <a href="projects.php" class="text-decoration-none text-dark">
                <div class="summary-card summary-prj text-center">
                    <div class="d-flex justify-content-center mb-2"><i class="fa fa-diagram-project card-icon"></i></div>
                    <h6 class="fw-semibold mb-2">Projects</h6>
                    <div class="progress mb-2">
                        <div class="progress-bar" role="progressbar" style="width: <?= $prjPct ?>%;" aria-valuenow="<?= $prjPct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="small text-muted mb-0"><?= $projectsCount ?> file<?= $projectsCount === 1 ? '' : 's' ?></p>
                </div>
            </a>
        </div>
        <div class="col-6 col-xl-3">
            <a href="File_Management.php" class="text-decoration-none text-dark">
                <div class="summary-card summary-total text-center">
                    <div class="d-flex justify-content-center mb-2"><i class="fa fa-folder-open card-icon"></i></div>
                    <h6 class="fw-semibold mb-2">Total files</h6>
                    <div class="progress mb-2">
                        <div class="progress-bar" role="progressbar" style="width: <?= $totalFiles > 0 ? 100 : 0 ?>%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="small text-muted mb-0"><?= $totalFiles ?> in library</p>
                </div>
            </a>
        </div>
    </div>

    <div class="row g-3">
        <!-- Recent Files -->
        <div class="col-lg-8">
            <div class="od-card-box">
                <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                    <h5 class="fw-semibold mb-0">Recent files</h5>
                    <a href="recent_files.php" class="text-decoration-none small">View all</a>
                </div>
                <div class="file-list" id="fileList" style="max-height: 400px; overflow-y: auto;">
                    <?php if ($recentFiles->num_rows > 0): ?>
                        <?php while ($file = $recentFiles->fetch_assoc()): ?>
                            <div class="file-item">
                                <div>
                                    <i class="fa fa-file me-2 text-primary"></i>
                                    <?= htmlspecialchars($file['filename']) ?>
                                    <div class="text-muted small">
                                        Modified <?= date("M d, Y h:i A", strtotime($file['uploaded_at'])) ?> • 
                                        <?= round($file['size'] / (1024*1024), 2) ?> MB
                                    </div>
                                </div>
                                <div>
                                    <a href="<?= htmlspecialchars($file['filepath']) ?>" class="btn btn-sm btn-outline-primary">Open</a>
                                    <a href="share_file.php?id=<?= $file['id'] ?>" class="btn btn-sm btn-outline-info ms-2">Share</a>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted">No recent files found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Documents Summary -->
        <div class="col-lg-4">
            <div class="od-card-box">
                <h6 class="fw-semibold mb-2">Documents Summary</h6>
                <div style="height:220px;"><canvas id="docSummaryChart"></canvas></div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('docSummaryChart'), {
    type: 'doughnut',
    data: {
        labels: ['Approved', 'Pending', 'Rejected'],
        datasets: [{ data: [<?= $statusCounts['Approved'] ?>, <?= $statusCounts['Pending'] ?>, <?= $statusCounts['Rejected'] ?>], backgroundColor: ['#10b981','#f59e0b','#ef4444'], borderWidth: 0 }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
});
document.getElementById('searchInput')?.addEventListener('input', function () {
    const q = (this.value || '').toLowerCase().trim();
    document.querySelectorAll('#fileList .file-item').forEach(function (el) {
        el.style.display = !q || el.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
});
</script>
</body>
</html>
