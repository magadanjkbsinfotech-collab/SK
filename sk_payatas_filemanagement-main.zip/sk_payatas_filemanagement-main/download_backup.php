<?php
require 'includes/config.php';

// Access control: admin only
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (strtolower($_SESSION['role'] ?? '') !== 'admin') { header('Location: official_dashboard.php'); exit; }

$file = basename($_GET['file'] ?? '');
if ($file === '' || !preg_match('/^skfilehub_backup_\d{8}_\d{6}\.zip$/', $file)) {
    http_response_code(400);
    echo "Invalid file.";
    exit;
}

$path = BASE_PATH . 'backups/' . $file;
if (!is_file($path)) {
    http_response_code(404);
    echo "Not found.";
    exit;
}

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;

