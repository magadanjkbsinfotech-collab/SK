<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
if (strtolower($_SESSION['role']) !== 'admin') {
    header('Location: admin_dashboard.php');
    exit;
}

$chkDel = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'deleted_at'");
$hasDel = $chkDel && $chkDel->num_rows > 0;
if ($chkDel) {
    $chkDel->free();
}

$search = trim($_GET['q'] ?? '');
$statusTab = strtolower(trim($_GET['status'] ?? 'all'));
if ($statusTab === '' || $statusTab === 'all') {
    $statusTab = 'all';
}
if ($statusTab === 'archive') {
    $statusTab = 'archived';
}

$tabOrder = ['all', 'pending', 'reviewed', 'approved', 'rejected', 'archived'];
$tabLabels = [
    'all' => 'All',
    'pending' => 'Pending',
    'reviewed' => 'Reviewed',
    'approved' => 'Approved',
    'rejected' => 'Rejected',
    'archived' => 'Archive',
];
if (!in_array($statusTab, $tabOrder, true)) {
    $statusTab = 'all';
}

$delWhere = $hasDel ? 'WHERE deleted_at IS NULL' : '';
$tabCounts = array_fill_keys($tabOrder, 0);
$tabCounts['all'] = (int)($mysqli->query("SELECT COUNT(*) AS t FROM files " . $delWhere)->fetch_assoc()['t'] ?? 0);

$cntRes = $mysqli->query("SELECT status, COUNT(*) AS c FROM files " . $delWhere . " GROUP BY status");
if ($cntRes) {
    while ($row = $cntRes->fetch_assoc()) {
        $c = (int)($row['c'] ?? 0);
        $s = strtolower(trim($row['status'] ?? ''));
        if ($s === '' || $s === 'pending') {
            $tabCounts['pending'] += $c;
        } elseif (in_array($s, ['reviewed', 'approved', 'rejected', 'archived'], true)) {
            $tabCounts[$s] += $c;
        } else {
            $tabCounts['pending'] += $c;
        }
    }
    $cntRes->free();
}

$where = [];
$params = [];
$types = '';
if ($hasDel) {
    $where[] = 'f.deleted_at IS NULL';
}
if ($statusTab === 'pending') {
    $where[] = "(f.status IS NULL OR TRIM(COALESCE(f.status,'')) = '' OR LOWER(TRIM(f.status)) = 'pending')";
} elseif (in_array($statusTab, ['reviewed', 'approved', 'rejected', 'archived'], true)) {
    $where[] = 'LOWER(TRIM(f.status)) = ?';
    $params[] = $statusTab;
    $types .= 's';
}
if ($search !== '') {
    $where[] = "(f.filename LIKE CONCAT('%',?,'%') OR COALESCE(u.fullname,'') LIKE CONCAT('%',?,'%') OR COALESCE(u.username,'') LIKE CONCAT('%',?,'%'))";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= 'sss';
}

$sql = 'SELECT f.*, COALESCE(u.fullname, u.username, "Unknown") as uploader FROM files f LEFT JOIN users u ON u.id = f.uploaded_by';
if (count($where) > 0) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY f.uploaded_at DESC LIMIT 200';

$files = null;
if (count($params) > 0) {
    $stmt = $mysqli->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $files = $stmt->get_result();
    }
} else {
    $files = $mysqli->query($sql);
}

function fs_status_tab_href(string $tab, string $search): string {
    $qs = [];
    if ($tab !== 'all') {
        $qs['status'] = $tab;
    }
    if ($search !== '') {
        $qs['q'] = $search;
    }
    $q = http_build_query($qs);
    return 'Ad_File_Status.php' . ($q !== '' ? '?' . $q : '');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>File Status | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
body { background-image: url('SK.png'); background-repeat: no-repeat; background-size: cover; background-attachment: fixed; }
.fs-list { display: block; width: 100%; overflow-x: hidden; }
.fs-row { display: grid; grid-template-columns: 60px 1fr 1fr 1fr 1fr 100px; gap: 1rem; align-items: center; padding: 0.75rem; border-bottom: 1px solid #e9ecef; font-size: 0.9rem; width: 100%; }
.fs-row.fs-head { background: #f8f9fa; font-weight: 600; position: sticky; top: 0; z-index: 10; }
.fs-row div { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.fs-file-info { display: flex; flex-direction: column; gap: 0.25rem; }
.fs-file-name { font-weight: 500; }
.fs-tracking-code { font-size: 0.85rem; color: #0d6efd; }
</style>
</head>
<body>
<?php include 'includes/nav_admin.php'; ?>

<div class="main">
    <div class="fm-page">
        <div class="row g-3">
            <div class="col-12">
        <div class="fm-topbar mb-3">
            <h4 class="mb-0 fw-semibold">File Status</h4>
            <div class="d-flex gap-2 align-items-center flex-wrap">
                <form class="d-flex gap-2 align-items-center flex-wrap" method="get" action="Ad_File_Status.php">
                    <div class="fm-search" style="min-width:220px;">
                        <input type="search" name="q" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Search file or uploader">
                    </div>
                    <?php if ($statusTab !== 'all'): ?>
                        <input type="hidden" name="status" value="<?= htmlspecialchars($statusTab) ?>">
                    <?php endif; ?>
                    <button type="submit" class="btn btn-light border">Search</button>
                </form>
                <button type="button" class="btn btn-light border d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#bulkUpdateModal">
                    <i class="fa fa-check-double"></i> Update
                </button>
                <button type="button" class="btn btn-light border d-flex align-items-center gap-2" data-bs-toggle="offcanvas" data-bs-target="#filtersCanvas">
                    <i class="fa fa-filter"></i> Filters
                </button>
            </div>
        </div>

        <ul class="nav fs-status-tabs mb-3 list-unstyled">
            <?php foreach ($tabOrder as $tab): ?>
                <li class="nav-item">
                    <a class="nav-link <?= $statusTab === $tab ? 'active' : '' ?>"
                       href="<?= htmlspecialchars(fs_status_tab_href($tab, $search)) ?>">
                        <?= htmlspecialchars($tabLabels[$tab]) ?>
                        <span class="fs-tab-count"><?= (int)($tabCounts[$tab] ?? 0) ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>

        <?php if (isset($_GET['ok'])): ?>
            <div class="alert alert-success">Updated successfully.</div>
        <?php elseif (isset($_GET['err'])): ?>
            <div class="alert alert-danger">Action failed. Please try again.</div>
        <?php endif; ?>

        <form action="update_status.php" method="POST" id="bulkForm">
            <div class="fs-list">
                <div class="fs-row fs-head">
                    <div>
                        <div class="fs-check" style="background:#fff;border:2px solid #0d6efd;color:#0d6efd;">
                            <input type="checkbox" id="checkAll" aria-label="Select all">
                        </div>
                    </div>
                    <div>File Name</div>
                    <div>Date Submitted</div>
                    <div>Status</div>
                    <div>Uploader</div>
                    <div class="text-end">Action</div>
                </div>

                <?php if ($files && $files->num_rows > 0): ?>
                    <?php while ($file = $files->fetch_assoc()): ?>
                        <?php
                            $st = strtolower(trim($file['status'] ?? ''));
                            if ($st === '') {
                                $st = 'pending';
                            }
                            $pillClass = in_array($st, ['pending', 'approved', 'rejected', 'reviewed', 'archived'], true) ? $st : 'archived';
                        ?>
                        <div class="fs-row">
                            <div>
                                <div class="fs-check">
                                    <input type="checkbox" class="row-check" name="file_ids[]" value="<?= (int)$file['id'] ?>" aria-label="Select">
                                </div>
                            </div>
                            <div class="fs-file-info">
                                <div class="fs-file-name"><?= htmlspecialchars($file['filename']) ?></div>
                                <div class="fs-tracking-code"><?= htmlspecialchars($file['tracking_code'] ?? '-') ?></div>
                            </div>
                            <div class="text-muted"><?= !empty($file['uploaded_at']) ? date('Y-m-d', strtotime($file['uploaded_at'])) : '-' ?></div>
                            <div>
                                <span class="fs-pill <?= $pillClass ?>">
                                    <span class="fs-dot"></span>
                                    <?= htmlspecialchars(ucfirst($st)) ?>
                                </span>
                            </div>
                            <div class="text-muted small">
                                <?= htmlspecialchars($file['uploader'] ?? 'Unknown') ?>
                            </div>
                            <div class="text-end">
                                <?php if (!empty($file['id'])): ?>
                                    <a href="view_file.php?id=<?= (int)$file['id'] ?>" class="btn btn-sm btn-outline-primary me-2">View</a>
                                    <button type="button"
                                            class="fs-kebab"
                                            title="More"
                                            data-bs-toggle="modal"
                                            data-bs-target="#fileDetailModal"
                                            data-id="<?= (int)$file['id'] ?>"
                                            data-status="<?= htmlspecialchars(ucfirst($st)) ?>"
                                            data-comment="<?= htmlspecialchars($file['admin_comment'] ?? '') ?>">
                                        ⋮
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="p-4 text-center text-muted">No files found.</div>
                <?php endif; ?>
            </div>

            <input type="hidden" name="status" id="bulkStatus" value="">
        </form>
            </div>
        </div>
    </div>
</div>

<!-- Filters offcanvas -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="filtersCanvas">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title">Filters</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
  </div>
  <div class="offcanvas-body">
    <form method="get" action="Ad_File_Status.php">
      <div class="mb-3">
        <label class="form-label">Status</label>
        <select class="form-select" name="status">
          <option value="all" <?= $statusTab === 'all' ? 'selected' : '' ?>>All</option>
          <option value="pending" <?= $statusTab === 'pending' ? 'selected' : '' ?>>Pending</option>
          <option value="reviewed" <?= $statusTab === 'reviewed' ? 'selected' : '' ?>>Reviewed</option>
          <option value="approved" <?= $statusTab === 'approved' ? 'selected' : '' ?>>Approved</option>
          <option value="rejected" <?= $statusTab === 'rejected' ? 'selected' : '' ?>>Rejected</option>
          <option value="archived" <?= $statusTab === 'archived' ? 'selected' : '' ?>>Archive</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Search</label>
        <input class="form-control" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Filename or uploader">
      </div>
      <button class="btn btn-primary w-100" type="submit">Apply</button>
    </form>
  </div>
</div>

<!-- Bulk update modal -->
<div class="modal fade" id="bulkUpdateModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Status</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="form-label">Set selected files to</label>
        <select class="form-select" id="statusSelect">
          <option value="Pending">Pending</option>
          <option value="Reviewed">Reviewed</option>
          <option value="Approved">Approved</option>
          <option value="Rejected">Rejected</option>
          <option value="Archived">Archived</option>
        </select>
        <p class="small text-muted mt-2 mb-0">Tip: Use the checkbox header to select all.</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-secondary" data-bs-dismiss="modal" type="button">Cancel</button>
        <button class="btn btn-primary" type="button" id="applyBulkBtn">Update</button>
      </div>
    </div>
  </div>
</div>

<!-- Single-file update & comment modal -->
<div class="modal fade" id="fileDetailModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="update_status.php">
        <div class="modal-header">
          <h5 class="modal-title">Update File</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="file_id" id="fd_file_id">
          <div class="mb-3">
            <label class="form-label">Status</label>
            <select class="form-select" name="status" id="fd_status">
              <?php foreach (['Pending', 'Reviewed', 'Approved', 'Rejected', 'Archived'] as $opt): ?>
                <option value="<?= $opt ?>"><?= $opt ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Admin Comment</label>
            <textarea name="admin_comment" id="fd_comment" class="form-control" rows="3"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" id="deleteFileBtn">Delete File</button>
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
const checkAll = document.getElementById('checkAll');
checkAll?.addEventListener('change', () => {
  document.querySelectorAll('.row-check').forEach(cb => { cb.checked = checkAll.checked; });
});

document.getElementById('applyBulkBtn')?.addEventListener('click', () => {
  const status = document.getElementById('statusSelect').value;
  document.getElementById('bulkStatus').value = status;
  document.getElementById('bulkForm').submit();
});

const detailModal = document.getElementById('fileDetailModal');
detailModal?.addEventListener('show.bs.modal', function (event) {
  const btn = event.relatedTarget;
  if (!btn) return;
  const id = btn.getAttribute('data-id');
  const status = btn.getAttribute('data-status') || 'Pending';
  const comment = btn.getAttribute('data-comment') || '';
  document.getElementById('fd_file_id').value = id;
  const sel = document.getElementById('fd_status');
  const norm = (status || '').toLowerCase();
  const map = { pending: 'Pending', reviewed: 'Reviewed', approved: 'Approved', rejected: 'Rejected', archived: 'Archived' };
  sel.value = map[norm] || 'Pending';
  document.getElementById('fd_comment').value = comment;
});

// Delete file functionality
document.getElementById('deleteFileBtn')?.addEventListener('click', function() {
  const fileId = document.getElementById('fd_file_id').value;
  if (!fileId) {
    alert('Error: File ID not found');
    return;
  }
  
  if (confirm('Are you sure you want to delete this file? This action cannot be undone.')) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'delete_file.php';
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'file_id';
    input.value = fileId;
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
  }
});
</script>
</body>
</html>
