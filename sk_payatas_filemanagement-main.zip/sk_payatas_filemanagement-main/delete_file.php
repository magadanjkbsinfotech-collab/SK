<?php
require 'includes/config.php';

// Access control: admin only
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: official_dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: Ad_File_Status.php');
    exit;
}

$file_id = (int)($_POST['file_id'] ?? 0);

if ($file_id <= 0) {
    header('Location: Ad_File_Status.php?err=invalid_file');
    exit;
}

try {
    $mysqli->begin_transaction();
    
    // Get file details before deletion
    $stmt = $mysqli->prepare("SELECT id, filepath, filename FROM files WHERE id = ?");
    if (!$stmt) {
        throw new Exception('prepare_failed');
    }
    
    $stmt->bind_param('i', $file_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('file_not_found');
    }
    
    $file = $result->fetch_assoc();
    $file_path = $file['filepath'] ?? '';
    $filename = $file['filename'] ?? 'Unknown';
    $stmt->close();
    
    // Delete physical file first (before marking as deleted in DB)
    if (!empty($file_path) && file_exists($file_path)) {
        if (!unlink($file_path)) {
            error_log("Warning: Could not delete file at: $file_path");
        }
    }
    
    // Soft delete: mark file as deleted instead of hard delete
    // This preserves the record and maintains referential integrity
    $stmt = $mysqli->prepare("UPDATE files SET deleted_at = NOW() WHERE id = ?");
    if (!$stmt) {
        throw new Exception('prepare_failed');
    }
    
    $stmt->bind_param('i', $file_id);
    if (!$stmt->execute()) {
        throw new Exception('file_delete_failed: ' . $stmt->error);
    }
    $stmt->close();
    
    // Log the deletion action (activity logs are preserved for audit trail)
    log_activity($file_id, "File deleted: {$filename}", $_SESSION['user_id'] ?? null);
    
    $mysqli->commit();
    
    header('Location: Ad_File_Status.php?ok=1');
    exit;
    
} catch (Exception $e) {
    $mysqli->rollback();
    error_log('Delete file error: ' . $e->getMessage());
    header('Location: Ad_File_Status.php?err=1');
    exit;
}
?>
