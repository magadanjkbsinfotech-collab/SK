<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: official_login.php'); exit; }
$user_id = $_SESSION['user_id'];

// Handle file metadata update (title & category)
$updateMessage = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_metadata') {
    $file_id = (int)($_POST['file_id'] ?? 0);
    $new_title = trim($_POST['file_title'] ?? '');
    $new_category = trim($_POST['file_category'] ?? '');
    
    if ($file_id <= 0) {
        $updateMessage = "<div class='alert alert-danger'>Invalid file ID.</div>";
    } elseif ($new_title === '') {
        $updateMessage = "<div class='alert alert-danger'>File title cannot be empty.</div>";
    } else {
        // Verify the file belongs to the user
        $chk = $mysqli->query("SELECT id, filename FROM files WHERE id = $file_id AND uploaded_by = $user_id");
        if ($chk && $chk->num_rows > 0) {
            $file_row = $chk->fetch_assoc();
            $old_filename = $file_row['filename'];
            
            // Extract file extension
            $file_ext = '';
            if (strpos($old_filename, '.') !== false) {
                $file_ext = substr($old_filename, strrpos($old_filename, '.'));
            }
            
            // Create new filename with extension preserved
            $new_filename = $new_title . $file_ext;
            
            $update_stmt = $mysqli->prepare("UPDATE files SET filename = ?, subject = ?, category = ? WHERE id = ? AND uploaded_by = ?");
            $update_stmt->bind_param("sssii", $new_filename, $new_title, $new_category, $file_id, $user_id);
            if ($update_stmt->execute()) {
                $updateMessage = "<div class='alert alert-success'>File updated successfully.</div>";
                // Log the activity
                if (function_exists('log_activity')) {
                    log_activity($file_id, "File renamed from '{$old_filename}' to '{$new_filename}' and category changed to '{$new_category}'", $user_id);
                }
            } else {
                $updateMessage = "<div class='alert alert-danger'>Failed to update file.</div>";
            }
            $update_stmt->close();
        } else {
            $updateMessage = "<div class='alert alert-danger'>File not found or unauthorized.</div>";
        }
    }
}

$user_id = $_SESSION['user_id'];
$result = $mysqli->query("SELECT * FROM files WHERE uploaded_by = $user_id AND deleted_at IS NULL ORDER BY uploaded_at DESC");
$documentsCount = (int)($mysqli->query("SELECT COUNT(*) AS total FROM files WHERE uploaded_by = $user_id AND category = 'Documents' AND deleted_at IS NULL")->fetch_assoc()['total'] ?? 0);
$reportsCount = (int)($mysqli->query("SELECT COUNT(*) AS total FROM files WHERE uploaded_by = $user_id AND category = 'Reports' AND deleted_at IS NULL")->fetch_assoc()['total'] ?? 0);
$projectsCount = (int)($mysqli->query("SELECT COUNT(*) AS total FROM files WHERE uploaded_by = $user_id AND category = 'Projects' AND deleted_at IS NULL")->fetch_assoc()['total'] ?? 0);
$totalUserFiles = max(0, $documentsCount + $reportsCount + $projectsCount);
$docPct = $totalUserFiles > 0 ? round(($documentsCount / $totalUserFiles) * 100, 1) : 0;
$repPct = $totalUserFiles > 0 ? round(($reportsCount / $totalUserFiles) * 100, 1) : 0;
$prjPct = $totalUserFiles > 0 ? round(($projectsCount / $totalUserFiles) * 100, 1) : 0;
$approvedDocCount = 0;
$pendingDocCount = 0;
$rejectedDocCount = 0;
$statusWhere = " WHERE uploaded_by = $user_id AND category = 'Documents' AND deleted_at IS NULL";
$sc = $mysqli->query("SELECT status, COUNT(*) AS c FROM files" . $statusWhere . " GROUP BY status");
if ($sc) {
    while ($row = $sc->fetch_assoc()) {
        $s = ucfirst(strtolower(trim($row['status'] ?? '')));
        if ($s === 'Approved') $approvedDocCount = (int)$row['c'];
        elseif ($s === 'Rejected') $rejectedDocCount = (int)$row['c'];
        else $pendingDocCount += (int)$row['c'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Files | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body {
     background-image: url('SK.png');
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
}
.card-box{background:#fff;border-radius:12px;padding:25px;box-shadow:0 4px 12px rgba(0,0,0,0.05);}
.file-item{display:flex;justify-content:space-between;align-items:center;padding:10px;border-bottom:1px solid #eee;}
</style>
</head>
<body>

<?php include 'includes/nav_official.php'; ?>

<div class="main">
    <div class="fm-page">
        <div class="fm-topbar mb-3">
            <h4 class="mb-0 fw-semibold">My Files</h4>
            <div class="fm-search">
                <input type="search" id="searchInput" class="form-control" placeholder="Search files">
            </div>
        </div>

        <?= $updateMessage ?>

        <div class="row g-3">
            <div class="col-lg-4">
                <div class="card fm-quick-card h-100 p-3">
                    <h6 class="mb-3 text-muted">Quick Actions</h6>
                    <div class="fm-quick-actions">
                        <button onclick="createFolder()" class="btn btn-outline-secondary w-100 mb-2 text-start">
                            <i class="fa fa-folder-plus me-2"></i>Create New Folder
                        </button>
                        <button onclick="window.location='upload_file.php'" class="btn btn-outline-primary w-100 mb-3 text-start">
                            <i class="fa fa-upload me-2"></i>Upload Files
                        </button>
                        <form action="share_file.php" method="get">
                            <label class="small text-muted mb-1">Select file to share</label>
                            <div class="input-group">
                                <select name="id" class="form-select" required>
                                    <option value="" disabled selected>Select file</option>
                                    <?php
                                    $files = $mysqli->query("SELECT id, filename FROM files WHERE uploaded_by = $user_id AND deleted_at IS NULL ORDER BY uploaded_at DESC");
                                    while ($f = $files->fetch_assoc()):
                                    ?>
                                        <option value="<?= $f['id'] ?>"><?= htmlspecialchars($f['filename']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                                <button type="submit" class="btn btn-outline-info">
                                    <i class="fa fa-share"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="row g-3">
                    <div class="col-sm-4">
                        <a href="documents.php" class="text-decoration-none">
                            <div class="card h-100 border-0 shadow-sm p-3">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="fa fa-file-lines fa-2x text-primary"></i>
                                    <div class="ms-3">
                                        <h6 class="mb-1">Documents</h6>
                                        <p class="mb-0 text-muted small"><?= $documentsCount ?> file<?= $documentsCount === 1 ? '' : 's' ?></p>
                                    </div>
                                </div>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: <?= $docPct ?>%;" aria-valuenow="<?= $docPct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="small text-muted mt-2 mb-0"><?= $docPct ?>% of your files</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a href="reports.php" class="text-decoration-none">
                            <div class="card h-100 border-0 shadow-sm p-3">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="fa fa-chart-column fa-2x text-success"></i>
                                    <div class="ms-3">
                                        <h6 class="mb-1">Reports</h6>
                                        <p class="mb-0 text-muted small"><?= $reportsCount ?> file<?= $reportsCount === 1 ? '' : 's' ?></p>
                                    </div>
                                </div>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: <?= $repPct ?>%;" aria-valuenow="<?= $repPct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="small text-muted mt-2 mb-0"><?= $repPct ?>% of your files</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a href="projects.php" class="text-decoration-none">
                            <div class="card h-100 border-0 shadow-sm p-3">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="fa fa-diagram-project fa-2x text-warning"></i>
                                    <div class="ms-3">
                                        <h6 class="mb-1">Projects</h6>
                                        <p class="mb-0 text-muted small"><?= $projectsCount ?> file<?= $projectsCount === 1 ? '' : 's' ?></p>
                                    </div>
                                </div>
                                <div class="progress" style="height: 8px;">
                                    <div class="progress-bar bg-warning" role="progressbar" style="width: <?= $prjPct ?>%;" aria-valuenow="<?= $prjPct ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="small text-muted mt-2 mb-0"><?= $prjPct ?>% of your files</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-3 mt-1">
            <div class="col-lg-8">
                <div class="fm-card p-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <h6 class="mb-0">Recently Uploaded</h6>
                    </div>

                    <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                        <table class="table fm-table">
                            <thead>
                                <tr>
                                    <th style="white-space: nowrap;">Tracking code</th>
                                    <th>File Name</th>
                                    <th>Size</th>
                                    <th>Date &amp; Time</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="fileTableBody">
                            <?php if ($result->num_rows > 0): ?>
                                <?php while ($file = $result->fetch_assoc()): ?>
                                    <tr data-name="<?= htmlspecialchars(strtolower($file['filename'])) ?>">
                                        <td><?php echo $file['tracking_code']; ?></td>
                                        <td class="editable-filename" data-file-id="<?= $file['id'] ?>" data-file-category="<?= htmlspecialchars($file['category'] ?? '') ?>" style="cursor: pointer;">
                                            <i class="fa fa-file text-primary me-2"></i>
                                            <span class="filename-text" style="text-decoration: underline; color: #0d6efd;"><?= htmlspecialchars($file['filename']) ?></span>
                                        </td>
                                        <td><?= round($file['size'] / (1024*1024), 2) ?> MB</td>
                                        <td><?= date("M d, Y h:i A", strtotime($file['uploaded_at'])) ?></td>
                                        <td class="text-end">
                                            <a href="<?= htmlspecialchars($file['filepath']) ?>" class="btn btn-sm btn-outline-primary">Open</a>
                                            <a href="share_file.php?id=<?= $file['id'] ?>" class="btn btn-sm btn-outline-info ms-1">Share</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center text-muted">No files uploaded yet.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="fm-card p-3">
                    <h6 class="mb-3 fw-semibold">Documents Summary</h6>
                    <div style="height:220px;"><canvas id="docSummaryChart"></canvas></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Hidden form for filename update -->
<form id="filenameUpdateForm" method="POST" style="display: none;">
    <input type="hidden" name="action" value="update_metadata">
    <input type="hidden" name="file_id" id="updateFileId">
    <input type="hidden" name="file_title" id="updateFileTitle">
    <input type="hidden" name="file_category" id="updateFileCategory" value="">
</form>

<script>
// Inline filename editing
document.querySelectorAll('.editable-filename').forEach(cell => {
    cell.addEventListener('click', function(e) {
        if (e.target.classList.contains('filename-text') || e.target.closest('.filename-text')) {
            const filenameSpan = this.querySelector('.filename-text');
            const fullFilename = filenameSpan.textContent;
            const fileId = this.getAttribute('data-file-id');
            
            // Extract filename without extension
            const lastDotIndex = fullFilename.lastIndexOf('.');
            const fileExtension = lastDotIndex > 0 ? fullFilename.substring(lastDotIndex) : '';
            const filenameOnly = lastDotIndex > 0 ? fullFilename.substring(0, lastDotIndex) : fullFilename;
            
            // Create input field with filename only (no extension)
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control form-control-sm';
            input.value = filenameOnly;
            input.style.maxWidth = '300px';
            
            // Show extension after input
            const extensionLabel = document.createElement('small');
            extensionLabel.className = 'text-muted ms-2';
            extensionLabel.textContent = fileExtension;
            
            // Replace text with input and extension
            const wrapper = document.createElement('span');
            wrapper.appendChild(input);
            wrapper.appendChild(extensionLabel);
            filenameSpan.replaceWith(wrapper);
            input.focus();
            input.select();
            
            // Save on Enter or blur
            const saveFilename = () => {
                const newFilename = input.value.trim();
                if (newFilename && newFilename !== filenameOnly) {
                    // Submit the form with filename only (backend will add extension)
                    document.getElementById('updateFileId').value = fileId;
                    document.getElementById('updateFileTitle').value = newFilename;
                    document.getElementById('updateFileCategory').value = fileCategory;
                    document.getElementById('filenameUpdateForm').submit();
                } else if (newFilename) {
                    // Revert if no change
                    const newSpan = document.createElement('span');
                    newSpan.className = 'filename-text';
                    newSpan.style.textDecoration = 'underline';
                    newSpan.style.color = '#0d6efd';
                    newSpan.textContent = fullFilename;
                    wrapper.replaceWith(newSpan);
                }
            };
            
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') saveFilename();
                if (e.key === 'Escape') {
                    const newSpan = document.createElement('span');
                    newSpan.className = 'filename-text';
                    newSpan.style.textDecoration = 'underline';
                    newSpan.style.color = '#0d6efd';
                    newSpan.textContent = fullFilename;
                    wrapper.replaceWith(newSpan);
                }
            });
            input.addEventListener('blur', saveFilename);
        }
    });
});

// Simple client-side filter by filename
document.getElementById('searchInput')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('#fileTableBody tr').forEach(row => {
        const name = row.getAttribute('data-name') || '';
        row.style.display = name.includes(q) ? '' : 'none';
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('docSummaryChart'), {
    type: 'doughnut',
    data: {
        labels: ['Approved', 'Pending', 'Rejected'],
        datasets: [{ data: [<?= $approvedDocCount ?>, <?= $pendingDocCount ?>, <?= $rejectedDocCount ?>], backgroundColor: ['#10b981','#f59e0b','#ef4444'], borderWidth: 0 }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
});
</script>
</body>
</html>
