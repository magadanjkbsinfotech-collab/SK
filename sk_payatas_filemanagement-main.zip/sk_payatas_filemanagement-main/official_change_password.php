<?php
require 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: official_login.php');
    exit;
}
if (strtolower($_SESSION['role'] ?? '') !== 'official') {
    header('Location: index.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];

// Fetch flag (for extra safety)
$mustChange = 0;
$stmt = $mysqli->prepare("SELECT must_change_password FROM users WHERE id = ? LIMIT 1");
if ($stmt) {
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $mustChange = (int)($row['must_change_password'] ?? 0);
    $stmt->close();
}

if ($mustChange !== 1) {
    header('Location: official_dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($new === '' || $confirm === '') {
        $error = "Please fill in all fields.";
    } elseif ($new !== $confirm) {
        $error = "Passwords do not match.";
    } elseif (strlen($new) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $stmt = $mysqli->prepare("UPDATE users SET password = ?, must_change_password = 0 WHERE id = ?");
        $stmt->bind_param("si", $hash, $userId);
        if ($stmt->execute()) {
            $success = "Password updated successfully.";
            header('Location: official_dashboard.php');
            exit;
        } else {
            $error = "Failed to update password. Please try again.";
        }
        $stmt->close();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Set New Password | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background-image: url('SK.png');
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}
.card {
    width: 420px;
    border: none;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    background: #fff;
}
</style>
</head>
<body>
<div class="card p-4">
    <h4 class="mb-2 text-center">Set a new password</h4>
    <p class="text-muted text-center mb-3">For security, please create your own password before continuing.</p>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label class="form-label">New password</label>
            <input type="password" name="new_password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Confirm password</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <div class="d-grid">
            <button class="btn btn-primary">Save &amp; Continue</button>
        </div>
    </form>
</div>
</body>
</html>

