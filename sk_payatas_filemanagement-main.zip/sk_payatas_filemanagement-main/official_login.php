<?php
require 'includes/config.php';

// --- LOGIN LOGIC (Officials only) ---
if (isset($_POST['login'])) {
    $user = $mysqli->real_escape_string($_POST['username']);
    $pass = $_POST['password'];

    $stmt = $mysqli->prepare('SELECT id, username, password, role, fullname, must_change_password FROM users WHERE username = ? LIMIT 1');
    $stmt->bind_param('s', $user);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();

    if ($res && password_verify($pass, $res['password'])) {
        $role = strtolower(trim($res['role']));
        if ($role !== 'official') {
            $error = 'This login is for officials. Please use the Admin Login.';
        } else {
            $_SESSION['user_id'] = $res['id'];
            $_SESSION['username'] = $res['username'];
            $_SESSION['role'] = $res['role'];
            $_SESSION['fullname'] = $res['fullname'];

            $mustChange = (int)($res['must_change_password'] ?? 0);
            if ($mustChange === 1) {
                header('Location: official_change_password.php');
            } else {
                header('Location: official_dashboard.php');
            }
            exit;
        }
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SK FileHub | Officials Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-image: url('SK.png');
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        margin: 0;
        padding: 20px;
    }
    .card {
        width: 380px;
        border: none;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        background: #fff;
    }
    h4 {
        font-weight: 600;
        color: #333;
    }
    .btn-primary {
        background: #5f049c;
        border: none;
        transition: 0.3s;
    }
    .btn-primary:hover {
        background: #7d0781;
        transform: scale(1.03);
    }
    .title {
        text-align: center;
        font-size: 1.6rem;
        margin-bottom: 10px;
        color: #444;
    }
    .footer-note {
        text-align: center;
        font-size: 0.9rem;
        margin-top: 10px;
        color: #666;
    }
</style>
</head>
<body>

<div class="card p-4">
    <h4 class="title mb-3 text-center">Officials Login</h4>

    <?php if(!empty($error)): ?>
        <div class="alert alert-danger text-center"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <input name="username" class="form-control" placeholder="Username" required>
        </div>
        <div class="mb-3">
            <input name="password" type="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="d-grid mb-2">
            <button name="login" class="btn btn-primary">Login</button>
        </div>
    </form>

    <p class="footer-note">
        <a href="index.php">Login as Admin</a>
    </p>
</div>

</body>
</html>

