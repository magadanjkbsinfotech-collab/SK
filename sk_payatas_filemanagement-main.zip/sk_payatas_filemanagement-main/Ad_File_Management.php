<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (strtolower($_SESSION['role']) !== 'admin') { header('Location: admin_dashboard.php'); exit; }

$hasDel = false;
$chkDel = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'deleted_at'");
if ($chkDel && $chkDel->num_rows > 0) {
    @$mysqli->query("SELECT id FROM files WHERE deleted_at IS NULL LIMIT 1");
    if (!$mysqli->error) $hasDel = true;
}
if ($chkDel) $chkDel->free();
$andDel = $hasDel ? " AND deleted_at IS NULL" : "";
$delClause = $hasDel ? " WHERE deleted_at IS NULL" : "";

$SUBCATEGORIES = [
    'Report' => ['Minutes Of Meetings (MOM)','Accomplishment Reports','Financial Reports','Attendance Reports','Activity Reports','Audit / Compliance Report'],
    'Document' => ['Resolutions','Ordinances','Memorandums / Memos','Letters & Communications','Certificates','Forms & Templates','Policies & Guidelines','Legal / Reference Documents'],
    'Project' => ['Project Proposals','Approved Projects','Project Plans & Timelines','Budget & Funding Documents','Implementation Documents','Monitoring & Evaluation','Project Completion Reports','Photos & Media Files','Partner / Sponsor Documents'],
];

// Track filters (from GET when Track modal is used)
$trackUser = trim($_GET['track_user'] ?? '');
$trackMain = trim($_GET['track_main'] ?? '');
$trackSub = trim($_GET['track_sub'] ?? '');
$trackSeq = trim($_GET['track_seq'] ?? '');
$trackDate = trim($_GET['track_date'] ?? '');
$trackSubject = trim($_GET['track_subject'] ?? '');
$where = [$hasDel ? "f.deleted_at IS NULL" : "1=1"];
// If deleted_at column doesn't exist, avoid using it (page may load before migration)
$params = [];
$types = '';
if ($trackUser !== '') {
    $where[] = "(u.fullname LIKE CONCAT('%',?,'%') OR u.username LIKE CONCAT('%',?,'%'))";
    $params[] = $trackUser; $params[] = $trackUser;
    $types .= 'ss';
}
if ($trackMain !== '') {
    $catVal = $trackMain === 'Document' ? 'Documents' : ($trackMain === 'Report' ? 'Reports' : ($trackMain === 'Project' ? 'Projects' : $trackMain));
    $where[] = "f.category = ?";
    $params[] = $catVal;
    $types .= 's';
}
if ($trackSub !== '') {
    $where[] = "f.sub_category = ?";
    $params[] = $trackSub;
    $types .= 's';
}
if ($trackSeq !== '') {
    $where[] = "f.sequence = ?";
    $params[] = $trackSeq;
    $types .= 's';
}
if ($trackDate !== '') {
    $where[] = "(f.doc_date = ? OR DATE(f.uploaded_at) = ?)";
    $params[] = $trackDate; $params[] = $trackDate;
    $types .= 'ss';
}
if ($trackSubject !== '') {
    $where[] = "f.subject LIKE CONCAT('%',?,'%')";
    $params[] = $trackSubject;
    $types .= 's';
}
$trackWhere = " WHERE " . implode(" AND ", $where);

$docCount = (int)(@$mysqli->query("SELECT COUNT(*) AS c FROM files WHERE category='Documents'" . $andDel)->fetch_assoc()['c'] ?? 0);
$repCount = (int)(@$mysqli->query("SELECT COUNT(*) AS c FROM files WHERE category='Reports'" . $andDel)->fetch_assoc()['c'] ?? 0);
$projCount = (int)(@$mysqli->query("SELECT COUNT(*) AS c FROM files WHERE category='Projects'" . $andDel)->fetch_assoc()['c'] ?? 0);
$totalCat = $docCount + $repCount + $projCount ?: 1;

$sql = "SELECT f.*, u.fullname, u.username FROM files f LEFT JOIN users u ON f.uploaded_by = u.id" . $trackWhere . " ORDER BY f.uploaded_at DESC LIMIT 100";
if (count($params) > 0) {
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $recentFiles = $stmt->get_result();
} else {
    $recentFiles = $mysqli->query($sql);
}

$statusCounts = ['Approved'=>0,'Pending'=>0,'Rejected'=>0];
$sc = $mysqli->query("SELECT status, COUNT(*) AS c FROM files" . $delClause . " GROUP BY status");
if ($sc) {
    while ($row = $sc->fetch_assoc()) {
        $s = ucfirst(strtolower(trim($row['status'] ?? '')));
        if ($s === 'Approved') $statusCounts['Approved'] = (int)$row['c'];
        elseif ($s === 'Rejected') $statusCounts['Rejected'] = (int)$row['c'];
        else $statusCounts['Pending'] += (int)$row['c'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>File Manager | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body { background-image: url('SK.png'); background-repeat: no-repeat; background-size: cover; background-attachment: fixed; }
.fm-page { padding-top: 1.5rem; padding-bottom: 2.5rem; }
.fm-search-bar { display: flex; align-items: center; gap: 0.5rem; background: #fff; border-radius: 12px; padding: 0.5rem 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); flex: 1; max-width: 420px; }
.fm-search-bar input { border: none; flex: 1; }
.fm-search-bar input:focus { box-shadow: none; outline: none; }
.fm-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
.quick-actions .btn { border-radius: 8px; }
.cat-card { padding: 1.25rem; }
.cat-card .progress { height: 6px; background: #e9ecef; }
.cat-card .progress-bar { background: #0d6efd; }
.view-link { color: #0d6efd; text-decoration: none; font-size: 0.9rem; }
.view-link:hover { text-decoration: underline; }
.table th:first-child, .table td:first-child { max-width: 120px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.table th:nth-child(2), .table td:nth-child(2) { max-width: 100px; }
.table th:nth-child(3), .table td:nth-child(3) { max-width: 100px; }
</style>
</head>
<body>
<?php include 'includes/nav_admin.php'; ?>

<div class="main">
    <div class="fm-page">

        <!-- Top bar: title + search + Track (like other screens) -->
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h4 class="mb-0 fw-semibold">File Manager</h4>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <div class="fm-search-bar">
                    <i class="fa fa-search text-muted"></i>
                    <input type="search" id="searchFiles" class="form-control" placeholder="Search">
                    <i class="fa fa-sliders text-muted" style="cursor:pointer" title="Filters"></i>
                </div>
                <button type="button" class="btn btn-sm"
                        style="background:#a902ca;color:#fff;border:none;padding:0.5rem 1.25rem;border-radius:8px;"
                        data-bs-toggle="modal" data-bs-target="#trackModal">
                    <i class="fa fa-bolt me-1"></i> Track
                </button>
            </div>
        </div>

        <!-- ROW 1: Quick Actions + 3 stat cards -->
        <div class="row g-3 mb-3">
            <!-- Quick Actions (left) -->
            <div class="col-lg-4">
                <div class="fm-card p-3">
                    <h6 class="mb-3 fw-semibold">Quick Actions</h6>
                    <div class="d-grid gap-2">
                        <a href="upload_file.php" class="btn btn-outline-primary btn-sm">
                            <i class="fa fa-upload me-2"></i> Upload Files
                        </a>
                        <button type="button" class="btn btn-outline-secondary btn-sm"
                                data-bs-toggle="modal" data-bs-target="#trackModal">
                            <i class="fa fa-bolt me-2"></i> Track Files
                        </button>
                    </div>
                </div>
            </div>

            <!-- Stat cards (right) -->
            <div class="col-lg-8">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="fm-card p-3 text-center">
                            <div class="mb-1"><i class="fa fa-file-lines text-primary"></i></div>
                            <div class="fw-semibold">Documents</div>
                            <div class="text-muted small"><?= number_format($docCount) ?> Files</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="fm-card p-3 text-center">
                            <div class="mb-1"><i class="fa fa-file-alt text-primary"></i></div>
                            <div class="fw-semibold">Reports</div>
                            <div class="text-muted small"><?= number_format($repCount) ?> Files</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="fm-card p-3 text-center">
                            <div class="mb-1"><i class="fa fa-folder-open text-primary"></i></div>
                            <div class="fw-semibold">Projects</div>
                            <div class="text-muted small"><?= number_format($projCount) ?> Files</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ROW 2: Documents Summary (left) + Recently Uploaded (right) -->
        <div class="row g-3">
            <!-- Documents Summary left -->
            <div class="col-lg-4">
                <div class="fm-card p-3">
                    <h6 class="mb-3 fw-semibold">Documents Summary</h6>
                    <div style="height:220px;"><canvas id="docChart"></canvas></div>
                </div>
            </div>

            <!-- Recently Uploaded right -->
            <div class="col-lg-8">
                <div class="fm-card p-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0 fw-semibold">Recently Uploaded</h6>
                        <a href="Ad_File_Status.php" class="text-primary small text-decoration-none">View all &gt;</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>File Code</th>
                                    <th>Category</th>
                                    <th>Date&Time</th>
                                    <th>Subject</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="fileTableBody">
                                <?php if ($recentFiles && $recentFiles->num_rows > 0): ?>
                                    <?php while ($f = $recentFiles->fetch_assoc()): ?>
                                        <tr data-search="<?= htmlspecialchars(strtolower(($f['filename']??'').' '.($f['subject']??'').' '.($f['category']??'').' '.($f['sequence']??''))) ?>">
                                            <td><?= htmlspecialchars($f['sequence'] ?: $f['filename']) ?></td>
                                            <td><?= htmlspecialchars($f['category'] ?? '-') ?></td>
                                            <td><?= !empty($f['doc_date']) ? date("m.d.Y", strtotime($f['doc_date']))
                                                    : (!empty($f['uploaded_at']) ? date("m.d.Y H:i", strtotime($f['uploaded_at'])) : '-') ?></td>
                                            <td><?= htmlspecialchars($f['subject'] ?? '-') ?></td>
                                            <td>
                                                <?php if (!empty($f['id'])): ?>
                                                    <a href="view_file.php?id=<?= (int)$f['id'] ?>" class="text-primary small">view</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center text-muted py-4">No files yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Track Modal (outside main for proper Bootstrap display) -->
<div class="modal fade" id="trackModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius:12px;">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-semibold">Track Files</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-0">
                <form method="get" action="Ad_File_Management.php" id="trackForm">
                    <div class="mb-3">
                        <label class="form-label">User</label>
                        <input type="text" name="track_user" class="form-control" placeholder="" value="<?= htmlspecialchars($trackUser) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Main Category</label>
                        <select name="track_main" class="form-select">
                            <option value="">-- All --</option>
                            <option value="Document" <?= $trackMain==='Document'?'selected':'' ?>>Document</option>
                            <option value="Report" <?= $trackMain==='Report'?'selected':'' ?>>Report</option>
                            <option value="Project" <?= $trackMain==='Project'?'selected':'' ?>>Project</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sub Category</label>
                        <select name="track_sub" class="form-select">
                            <option value="">-- All --</option>
                            <?php foreach ($SUBCATEGORIES as $m => $subs): ?>
                                <?php foreach ($subs as $s): ?>
                                    <option value="<?= htmlspecialchars($s) ?>" <?= $trackSub===$s?'selected':'' ?>><?= htmlspecialchars($s) ?></option>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sequence</label>
                        <input type="text" name="track_seq" class="form-control" placeholder="Enter sequence number" value="<?= htmlspecialchars($trackSeq) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Date</label>
                        <input type="date" name="track_date" class="form-control" value="<?= htmlspecialchars($trackDate) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <input type="text" name="track_subject" class="form-control" placeholder="" value="<?= htmlspecialchars($trackSubject) ?>">
                    </div>
                    <div class="text-center pt-2">
                        <button type="submit" class="btn w-100" style="background:#a902ca;color:#fff;border:none;padding:0.6rem;border-radius:8px;"><i class="fa fa-bolt me-1"></i> Track</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.getElementById('searchFiles')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('#fileTableBody tr').forEach(r => {
        const t = r.getAttribute('data-search') || '';
        r.style.display = t.includes(q) ? '' : 'none';
    });
});
new Chart(document.getElementById('docChart'), {
    type: 'doughnut',
    data: {
        labels: ['Approved', 'Pending', 'Rejected'],
        datasets: [{ data: [<?= $statusCounts['Approved'] ?>, <?= $statusCounts['Pending'] ?>, <?= $statusCounts['Rejected'] ?>], backgroundColor: ['#10b981','#f59e0b','#ef4444'], borderWidth: 0 }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
});
</script>
</body>
</html>
