<?php
require 'includes/config.php';

if (!isset($_GET['id'])) {
    die('File id required');
}

$id = (int)$_GET['id'];

$stmt = $mysqli->prepare("SELECT * FROM files WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$file = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$file) {
    die('File not found');
}

$filepath = $file['filepath'] ?? '';
if ($filepath === '' || !is_file($filepath)) {
    die('File missing on server');
}

// Determine extension for preview
$ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));

$isImage = in_array($ext, ['jpg','jpeg','png','gif','webp']);
$isPdf   = ($ext === 'pdf');
$isText  = in_array($ext, ['txt','csv','log']);

// Decide which nav to show
$role = strtolower($_SESSION['role'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View File | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body {
  background-image: url('SK.png');
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
}
.viewer-main {
  margin-left: 270px;
  padding: 1.5rem;
}
.viewer-card {
  background:#fff;
  border-radius:12px;
  box-shadow:0 4px 12px rgba(0,0,0,0.05);
  padding:1.25rem;
}
.viewer-frame {
  width:100%;
  border-radius:8px;
  border:1px solid #dee2e6;
  min-height:70vh;
}
.viewer-header {
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:.75rem;
  margin-bottom:1rem;
}
</style>
</head>
<body>
<?php
if ($role === 'admin') {
    include 'includes/nav_admin.php';
} else {
    include 'includes/nav_official.php';
}
?>
<div class="viewer-main">
  <div class="viewer-card">
    <div class="viewer-header">
      <div>
        <h5 class="mb-0"><?= htmlspecialchars($file['filename']) ?></h5>
        <small class="text-muted"><?= htmlspecialchars($file['category'] ?? '') ?></small>
      </div>
      <div class="d-flex gap-2">
        <a href="javascript:history.back()" class="btn btn-outline-secondary btn-sm">
          <i class="fa fa-times me-1"></i> Close
        </a>
        <a href="<?= htmlspecialchars($filepath) ?>" class="btn btn-primary btn-sm" target="_blank">
          <i class="fa fa-download me-1"></i> Open / Download
        </a>
      </div>
    </div>

    <?php if ($isImage): ?>
      <img src="<?= htmlspecialchars($filepath) ?>" alt="Preview" class="viewer-frame" style="object-fit:contain;">
    <?php elseif ($isPdf): ?>
      <embed src="<?= htmlspecialchars($filepath) ?>#toolbar=1" type="application/pdf" class="viewer-frame">
    <?php elseif ($isText): ?>
      <iframe src="<?= htmlspecialchars($filepath) ?>" class="viewer-frame"></iframe>
    <?php else: ?>
      <p class="text-muted">
        Preview is not available for this file type. Use the <strong>Open / Download</strong> button to view it.
      </p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>

