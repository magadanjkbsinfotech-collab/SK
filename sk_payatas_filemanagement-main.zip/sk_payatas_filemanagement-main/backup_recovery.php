<?php
require 'includes/config.php';

// Access control: admin only
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (strtolower($_SESSION['role'] ?? '') !== 'admin') { header('Location: official_dashboard.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: Ad_Storages.php');
    exit;
}

function table_exists(mysqli $mysqli, string $table): bool {
    $stmt = $mysqli->prepare("SHOW TABLES LIKE ?");
    $stmt->bind_param("s", $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $exists = $res && $res->num_rows > 0;
    $stmt->close();
    return $exists;
}

function sql_dump_database(mysqli $mysqli, string $dbName): string {
    $out = "-- SK FileHub Backup\n";
    $out .= "-- Database: {$dbName}\n";
    $out .= "-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
    $out .= "SET FOREIGN_KEY_CHECKS=0;\n";
    $out .= "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n\n";

    $tablesRes = $mysqli->query("SHOW TABLES");
    if (!$tablesRes) return $out . "-- Failed to list tables\n";

    $tables = [];
    while ($row = $tablesRes->fetch_array()) {
        $tables[] = $row[0];
    }

    foreach ($tables as $table) {
        $createRes = $mysqli->query("SHOW CREATE TABLE `{$table}`");
        if ($createRes) {
            $cr = $createRes->fetch_assoc();
            $createSql = $cr['Create Table'] ?? '';
            if ($createSql !== '') {
                $out .= "\n-- ----------------------------\n";
                $out .= "-- Table structure for `{$table}`\n";
                $out .= "-- ----------------------------\n";
                $out .= "DROP TABLE IF EXISTS `{$table}`;\n";
                $out .= $createSql . ";\n\n";
            }
        }

        $dataRes = $mysqli->query("SELECT * FROM `{$table}`");
        if (!$dataRes) continue;

        $fields = [];
        $fieldCount = $dataRes->field_count;
        $fieldMeta = $dataRes->fetch_fields();
        for ($i=0; $i<$fieldCount; $i++) $fields[] = $fieldMeta[$i]->name;

        $out .= "-- ----------------------------\n";
        $out .= "-- Records of `{$table}`\n";
        $out .= "-- ----------------------------\n";

        while ($row = $dataRes->fetch_assoc()) {
            $cols = array_map(fn($f) => "`{$f}`", $fields);
            $vals = [];
            foreach ($fields as $f) {
                $v = $row[$f];
                if ($v === null) $vals[] = "NULL";
                else $vals[] = "'" . $mysqli->real_escape_string((string)$v) . "'";
            }
            $out .= "INSERT INTO `{$table}` (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ");\n";
        }
        $out .= "\n";
    }

    $out .= "SET FOREIGN_KEY_CHECKS=1;\n";
    return $out;
}

function add_dir_to_zip(ZipArchive $zip, string $dirPath, string $zipBase): void {
    if (!is_dir($dirPath)) return;
    $dirPath = rtrim($dirPath, "/\\") . DIRECTORY_SEPARATOR;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dirPath, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    foreach ($it as $file) {
        /** @var SplFileInfo $file */
        if (!$file->isFile()) continue;
        $full = $file->getPathname();
        $rel = substr($full, strlen($dirPath));
        $zip->addFile($full, rtrim($zipBase, "/") . "/" . str_replace("\\", "/", $rel));
    }
}

function clear_storage(mysqli $mysqli): array {
    $deletedFiles = 0;
    $deletedBytes = 0;

    // Delete files from disk based on DB paths
    if (table_exists($mysqli, 'files')) {
        $res = $mysqli->query("SELECT id, filepath, size FROM files");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $path = (string)($row['filepath'] ?? '');
                $size = (int)($row['size'] ?? 0);
                if ($path !== '' && strpos($path, '..') === false) {
                    $full = BASE_PATH . ltrim(str_replace(['\\'], ['/'], $path), '/');
                    if (is_file($full)) {
                        $deletedBytes += filesize($full) ?: $size;
                        @unlink($full);
                        $deletedFiles++;
                    }
                }
            }
        }
    }

    // Clear DB tables that reference files
    $mysqli->begin_transaction();
    try {
        if (table_exists($mysqli, 'shared_files')) $mysqli->query("DELETE FROM shared_files");
        if (table_exists($mysqli, 'activity_log')) $mysqli->query("DELETE FROM activity_log");
        if (table_exists($mysqli, 'files')) $mysqli->query("DELETE FROM files");
        $mysqli->commit();
    } catch (Throwable $e) {
        $mysqli->rollback();
        throw $e;
    }

    return ['files'=>$deletedFiles,'bytes'=>$deletedBytes];
}

$action = '';
if (isset($_POST['backup'])) $action = 'backup';
elseif (isset($_POST['clear'])) $action = 'clear';
elseif (isset($_POST['backup_clear'])) $action = 'backup_clear';
else $action = 'backup';

$backupName = 'skfilehub_backup_' . date('Ymd_His') . '.zip';
$backupsDir = BASE_PATH . 'backups/';
if (!is_dir($backupsDir)) @mkdir($backupsDir, 0755, true);

// Create zip in a temp file
$tmpZipPath = tempnam(sys_get_temp_dir(), 'skfh_');
if ($tmpZipPath === false) {
    header('Location: Ad_Storages.php?err=tmp');
    exit;
}
// tempnam creates a file without .zip; ZipArchive can still open it

if ($action === 'backup' || $action === 'backup_clear') {
    $zip = new ZipArchive();
    if ($zip->open($tmpZipPath, ZipArchive::OVERWRITE) !== true) {
        @unlink($tmpZipPath);
        header('Location: Ad_Storages.php?err=zip');
        exit;
    }

    // SQL dump
    $sql = sql_dump_database($mysqli, DB_NAME);
    $zip->addFromString('backup.sql', $sql);

    // Uploads folder
    add_dir_to_zip($zip, UPLOAD_DIR, 'uploads');

    $zip->close();
}

if ($action === 'backup') {
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $backupName . '"');
    header('Content-Length: ' . filesize($tmpZipPath));
    readfile($tmpZipPath);
    @unlink($tmpZipPath);
    exit;
}

if ($action === 'backup_clear') {
    // Store backup server-side then clear
    $finalPath = $backupsDir . $backupName;
    @rename($tmpZipPath, $finalPath);

    try {
        $stats = clear_storage($mysqli);
        header('Location: Ad_Storages.php?ok=backup_clear&file=' . urlencode($backupName) . '&n=' . $stats['files']);
        exit;
    } catch (Throwable $e) {
        header('Location: Ad_Storages.php?err=clear_failed');
        exit;
    }
}

if ($action === 'clear') {
    @unlink($tmpZipPath);

    // Require explicit confirm
    if (($_POST['confirm'] ?? '') !== '1') {
        header('Location: Ad_Storages.php?err=confirm_required');
        exit;
    }
    try {
        $stats = clear_storage($mysqli);
        header('Location: Ad_Storages.php?ok=cleared&n=' . $stats['files']);
        exit;
    } catch (Throwable $e) {
        header('Location: Ad_Storages.php?err=clear_failed');
        exit;
    }
}

@unlink($tmpZipPath);
header('Location: Ad_Storages.php');
exit;

