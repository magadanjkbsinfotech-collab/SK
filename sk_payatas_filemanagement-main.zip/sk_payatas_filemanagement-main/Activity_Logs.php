<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }

// Filters for Track modal / query string
$filterUser  = trim($_GET['user'] ?? '');
$filterAction = trim($_GET['action'] ?? '');
$filterDate  = trim($_GET['date'] ?? '');

$where = [];
$params = [];
$types  = '';

if ($filterUser !== '') {
    $where[] = "(COALESCE(o.name, u.fullname, u.username, '') LIKE CONCAT('%',?,'%'))";
    $params[] = $filterUser;
    $types   .= 's';
}
if ($filterAction !== '') {
    $where[] = "a.action LIKE CONCAT('%',?,'%')";
    $params[] = $filterAction;
    $types   .= 's';
}
if ($filterDate !== '') {
    $where[] = "DATE(a.created_at) = ?";
    $params[] = $filterDate;
    $types   .= 's';
}

$sql = "
    SELECT a.action, a.created_at, a.file_id, f.filepath, f.filename,
           COALESCE(o.name, u.fullname, u.username, 'System') AS username
    FROM activity_log a
    LEFT JOIN files f ON a.file_id = f.id
    LEFT JOIN officials o ON a.official_id = o.id
    LEFT JOIN users u ON f.uploaded_by = u.id
";
if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY a.created_at DESC LIMIT 100";

if ($where) {
    $stmt = $mysqli->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $logs = $stmt->get_result();
    } else {
        $logs = false;
    }
} else {
    $logs = @$mysqli->query($sql);
}
if (!$logs) $logs = false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Activity Log | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body { background-image: url('SK.png'); background-repeat: no-repeat; background-size: cover; background-attachment: fixed; }
.activity-search-bar { display: flex; align-items: center; gap: 0.5rem; background: #fff; border-radius: 12px; padding: 0.5rem 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); flex: 1; max-width: 480px; }
.activity-search-bar input { border: none; flex: 1; }
.activity-search-bar input:focus { box-shadow: none; outline: none; }
.btn-track { background: #a902ca !important; border-color: #a902ca !important; color: #fff; padding: 0.5rem 1.25rem; border-radius: 8px; }
.btn-track:hover { background: #8a0299 !important; border-color: #8a0299 !important; color: #fff; }
.recent-activities-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
.activity-table th { color: #6c757d; font-weight: 600; font-size: 0.85rem; }
.activity-table tbody tr:hover { background: #f8f9fa; }
.view-link { color: #0d6efd; text-decoration: none; }
.view-link:hover { text-decoration: underline; }
</style>
</head>
<body>
<?php include 'includes/nav_admin.php'; ?>
<div class="main">
    <div class="fm-page">
        <div class="fm-topbar mb-3 d-flex justify-content-between align-items-center flex-wrap gap-3">
            <h4 class="mb-0 fw-semibold">Activity Log</h4>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <div class="activity-search-bar">
                    <i class="fa fa-search text-muted"></i>
                    <input type="search" id="activitySearch" class="form-control" placeholder="Search and Track">
                    <i class="fa fa-sliders text-muted" style="cursor:pointer" title="Filters"></i>
                </div>
                <button type="button" class="btn btn-track" data-bs-toggle="modal" data-bs-target="#activityTrackModal">
                    <i class="fa fa-bolt me-1"></i> Track
                </button>
            </div>
        </div>

        <div class="recent-activities-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0 fw-semibold">Recent Activities</h5>
                <button type="button" class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-2">
                    <i class="fa fa-filter"></i> Filters
                </button>
            </div>

            <div class="table-responsive">
                <table class="table activity-table mb-0">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Action</th>
                            <th>Timestamp</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="activityTableBody">
                    <?php if ($logs && $logs->num_rows > 0): ?>
                        <?php while ($row = $logs->fetch_assoc()): ?>
                            <tr data-search="<?= htmlspecialchars(strtolower(($row['username'] ?? '').' '.($row['action'] ?? '').' '.($row['filename'] ?? ''))) ?>">
                                <td><?= htmlspecialchars($row['username'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['action'] ?? '-') ?></td>
                                <td><?= !empty($row['created_at']) ? date("m.d.Y", strtotime($row['created_at'])) : '-' ?></td>
                                <td class="text-end">
                                    <?php if (!empty($row['file_id'])): ?>
                                        <a href="view_file.php?id=<?= (int)$row['file_id'] ?>" class="view-link small">view</a>
                                    <?php else: ?>
                                        <span class="text-muted small">—</span>
                                    <?php endif; ?>
                                    <i class="fa fa-chevron-right ms-1 text-muted small"></i>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center text-muted py-4">No activity recorded yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-end mt-3">
                <a href="#" class="text-primary small text-decoration-none">View all</a>
            </div>
        </div>
    </div>
</div>

<!-- Track modal -->
<div class="modal fade" id="activityTrackModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:12px;">
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title fw-semibold">Track Activities</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body pt-0">
        <form method="get" action="Activity_Logs.php">
          <div class="mb-3">
            <label class="form-label">User</label>
            <input type="text" name="user" class="form-control"
                   value="<?= htmlspecialchars($filterUser) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Action</label>
            <input type="text" name="action" class="form-control"
                   value="<?= htmlspecialchars($filterAction) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Date</label>
            <input type="date" name="date" class="form-control"
                   value="<?= htmlspecialchars($filterDate) ?>">
          </div>
          <div class="text-center pt-2">
            <button type="submit" class="btn w-100"
                    style="background:#a902ca;color:#fff;border:none;padding:0.6rem;border-radius:8px;">
              <i class="fa fa-bolt me-1"></i> Track
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('activitySearch')?.addEventListener('input', function () {
    const q = this.value.toLowerCase();
    document.querySelectorAll('#activityTableBody tr').forEach(row => {
        if (row.cells.length < 2) return;
        const text = row.getAttribute('data-search') || '';
        row.style.display = text.includes(q) ? '' : 'none';
    });
});
</script>
</body>
</html>
