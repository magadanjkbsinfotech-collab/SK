<?php
require 'includes/config.php';

// Access control: admin only
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (strtolower($_SESSION['role'] ?? '') !== 'admin') { header('Location: official_dashboard.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: Ad_File_Status.php');
    exit;
}

$status = trim($_POST['status'] ?? '');
$comment = trim($_POST['admin_comment'] ?? '');
$allowed = ['Pending','Reviewed','Approved','Archived','Rejected'];
if (!in_array($status, $allowed, true)) {
    header('Location: Ad_File_Status.php?err=invalid_status');
    exit;
}

// Bulk update support
$ids = [];
if (isset($_POST['file_ids']) && is_array($_POST['file_ids'])) {
    foreach ($_POST['file_ids'] as $id) {
        $id = (int)$id;
        if ($id > 0) $ids[] = $id;
    }
} elseif (isset($_POST['file_id'])) {
    $id = (int)$_POST['file_id'];
    if ($id > 0) $ids[] = $id;
}

$ids = array_values(array_unique($ids));
if (count($ids) === 0) {
    header('Location: Ad_File_Status.php?err=no_selection');
    exit;
}

// Update in a transaction
$mysqli->begin_transaction();
try {
    // Check if admin_comment column exists; fall back if it doesn't
    $hasComment = false;
    $resCol = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'admin_comment'");
    if ($resCol && $resCol->num_rows > 0) $hasComment = true;
    if ($resCol) $resCol->free();

    if ($hasComment) {
        $stmt = $mysqli->prepare("UPDATE files SET status = ?, admin_comment = ? WHERE id = ?");
        if (!$stmt) throw new Exception('prepare_failed');
        foreach ($ids as $id) {
            $stmt->bind_param("ssi", $status, $comment, $id);
            if (!$stmt->execute()) throw new Exception('execute_failed');
            if (function_exists('log_activity')) {
                log_activity($id, "Status set to {$status}", $_SESSION['user_id'] ?? null);
            }
        }
        $stmt->close();
    } else {
        $stmt = $mysqli->prepare("UPDATE files SET status = ? WHERE id = ?");
        if (!$stmt) throw new Exception('prepare_failed_no_comment');
        foreach ($ids as $id) {
            $stmt->bind_param("si", $status, $id);
            if (!$stmt->execute()) throw new Exception('execute_failed_no_comment');
            if (function_exists('log_activity')) {
                log_activity($id, "Status set to {$status}", $_SESSION['user_id'] ?? null);
            }
        }
        $stmt->close();
    }

    $mysqli->commit();
    header('Location: Ad_File_Status.php?ok=1');
    exit;
} catch (Throwable $e) {
    $mysqli->rollback();
    header('Location: Ad_File_Status.php?err=update_failed');
    exit;
}

