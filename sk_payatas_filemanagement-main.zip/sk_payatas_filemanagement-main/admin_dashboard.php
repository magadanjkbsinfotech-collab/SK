<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (strtolower($_SESSION['role']) !== 'admin') { header('Location: official_dashboard.php'); exit; }

$chkDel = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'deleted_at'");
$hasDel = $chkDel && $chkDel->num_rows > 0;
if ($chkDel) $chkDel->free();
$totalFiles = (int)($mysqli->query("SELECT COUNT(*) AS total FROM files" . ($hasDel ? " WHERE deleted_at IS NULL" : ""))->fetch_assoc()['total'] ?? 0);

$storageUsed = (int)($mysqli->query("SELECT COALESCE(SUM(size),0) AS total FROM files" . ($hasDel ? " WHERE deleted_at IS NULL" : ""))->fetch_assoc()['total'] ?? 0);
$storageGB = round($storageUsed / (1024 * 1024 * 1024), 2);
$totalSpaceGB = 364;
$usedPercent = min(100, round(($storageGB / $totalSpaceGB) * 100));
$availableGB = max(0, $totalSpaceGB - $storageGB);

$recentActivityCount = 0;
if (@$mysqli->query("SHOW TABLES LIKE 'activity_log'")->num_rows > 0) {
    $ra = @$mysqli->query("SELECT COUNT(*) AS c FROM activity_log WHERE created_at >= NOW() - INTERVAL 24 HOUR");
    if ($ra) $recentActivityCount = (int)($ra->fetch_assoc()['c'] ?? 0);
}

$pendingWhere = "WHERE (f.status IS NULL OR f.status = '' OR LOWER(TRIM(f.status)) = 'pending')";
if ($hasDel) $pendingWhere .= " AND f.deleted_at IS NULL";
$pendingDocs = $mysqli->query("
    SELECT f.id, f.filename, f.category, f.subject, f.doc_date, f.uploaded_at, u.fullname, u.username
    FROM files f
    LEFT JOIN users u ON f.uploaded_by = u.id
    " . $pendingWhere . "
    ORDER BY f.uploaded_at DESC
    LIMIT 10
");

$statusCounts = ['Approved'=>0,'Pending'=>0,'Rejected'=>0];
$statusWhere = $hasDel ? " WHERE deleted_at IS NULL" : "";
$sc = $mysqli->query("SELECT status, COUNT(*) AS c FROM files" . $statusWhere . " GROUP BY status");
if ($sc) {
    while ($row = $sc->fetch_assoc()) {
        $s = ucfirst(strtolower(trim($row['status'] ?? '')));
        if ($s === 'Approved') $statusCounts['Approved'] = (int)$row['c'];
        elseif ($s === 'Rejected') $statusCounts['Rejected'] = (int)$row['c'];
        else $statusCounts['Pending'] += (int)$row['c'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="css/style.css">
<style>
body { background-image: url('SK.png'); background-repeat: no-repeat; background-size: cover; background-attachment: fixed; }
.dash-topbar { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem; }
.dash-search-bar { display: flex; align-items: center; gap: 0.5rem; background: #fff; border-radius: 12px; padding: 0.5rem 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); flex: 1; max-width: 400px; }
.dash-search-bar input { border: none; flex: 1; }
.dash-search-bar input:focus { box-shadow: none; outline: none; }
.btn-upload-purple { background: #a902ca !important; border-color: #a902ca !important; color: #fff; }
.btn-upload-purple:hover { background: #8c02a8 !important; border-color: #8c02a8 !important; color: #fff; }
.summary-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); padding: 1.25rem; }
.summary-card .card-icon { color: #0d6efd; font-size: 1.25rem; }
.summary-card .progress { height: 8px; background: #e9ecef; }
.summary-card .progress-bar { background: #0d6efd; }
.gauge-circle { width: 160px; height: 160px; border-radius: 50%; background: conic-gradient(#0d6efd 0deg calc(var(--pct, 0) * 3.6deg), #e9ecef calc(var(--pct, 0) * 3.6deg) 360deg); }
</style>
</head>
<body>
<?php include 'includes/nav_admin.php'; ?>

<div class="main">
    <div class="dash-topbar">
        <h4 class="mb-0 fw-semibold">Dashboard-Admin</h4>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <div class="dash-search-bar">
                <i class="fa fa-search text-muted"></i>
                <input type="search" class="form-control" placeholder="Search">
                <i class="fa fa-sliders text-muted" style="cursor:pointer" title="Filters"></i>
            </div>
            <a href="upload_file.php" class="btn btn-upload-purple btn-primary"><i class="fa fa-plus me-1"></i> Upload File</a>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="summary-card">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <i class="fa fa-file-lines card-icon"></i>
                    <span class="text-muted small">Total Files</span>
                </div>
                <div class="progress mb-2">
                    <div class="progress-bar" style="width: <?= min(100, $totalFiles > 0 ? 85 : 0) ?>%"></div>
                </div>
                <h5 class="mb-0"><?= number_format($totalFiles) ?> Files</h5>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-card">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <i class="fa fa-clipboard-list card-icon"></i>
                    <span class="text-muted small">Activity Log</span>
                </div>
                <div class="progress mb-2">
                    <div class="progress-bar" style="width: <?= $recentActivityCount > 0 ? 60 : 10 ?>%"></div>
                </div>
                <h5 class="mb-0"><?= $recentActivityCount > 0 ? $recentActivityCount . ' Recent Action' : 'No Recent Action' ?></h5>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-card">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <i class="fa fa-database card-icon"></i>
                    <span class="text-muted small">Storage Usage</span>
                </div>
                <div class="progress mb-2">
                    <div class="progress-bar" style="width: <?= $usedPercent ?>%"></div>
                </div>
                <h5 class="mb-0"><?= $usedPercent ?>% Used Space</h5>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <!-- Pending Documents -->
        <div class="col-lg-7">
            <div class="summary-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0 fw-semibold">Pending Documents</h6>
                    <a href="Ad_File_Status.php" class="text-primary small text-decoration-none">View all &gt;</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead>
                            <tr><th>Name</th><th>Category</th><th>Date</th><th>Uploaded by</th><th></th></tr>
                        </thead>
                        <tbody>
                            <?php if ($pendingDocs && $pendingDocs->num_rows > 0): ?>
                                <?php while ($row = $pendingDocs->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['filename']) ?></td>
                                        <td><?= htmlspecialchars($row['category'] ?? '-') ?></td>
                                        <td><?= !empty($row['doc_date']) ? date("m.d.Y", strtotime($row['doc_date'])) : (!empty($row['uploaded_at']) ? date("m.d.Y", strtotime($row['uploaded_at'])) : '-') ?></td>
                                        <td><?= htmlspecialchars($row['fullname'] ?? $row['username'] ?? '-') ?></td>
                                        <td><i class="fa fa-chevron-right text-muted small"></i></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center text-muted py-3">No pending documents.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Right: Storage Gauge + Documents Summary -->
        <div class="col-lg-5">
            <div class="summary-card mb-3 text-center">
                <h6 class="mb-3 fw-semibold">Storage</h6>
                <div class="d-flex justify-content-center mb-2">
                    <div class="gauge-circle" style="--pct: <?= $usedPercent ?>"></div>
                </div>
                <p class="mb-1 small">Used : <?= $storageGB ?> GB</p>
                <p class="mb-1 small text-success">Available : <?= $availableGB ?> GB</p>
                <p class="mb-0 small text-muted">Total Space : <?= $totalSpaceGB ?> GB</p>
            </div>
            <div class="summary-card">
                <h6 class="mb-3 fw-semibold">Documents Summary</h6>
                <div style="height:220px;"><canvas id="docSummaryChart"></canvas></div>
            </div>
        </div>
    </div>
</div>

<script>
new Chart(document.getElementById('docSummaryChart'), {
    type: 'doughnut',
    data: {
        labels: ['Approved', 'Pending', 'Rejected'],
        datasets: [{
            data: [<?= $statusCounts['Approved'] ?>, <?= $statusCounts['Pending'] ?>, <?= $statusCounts['Rejected'] ?>],
            backgroundColor: ['#10b981','#f59e0b','#ef4444'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'bottom' }
        }
    }
});
</script>
</body>
</html>
