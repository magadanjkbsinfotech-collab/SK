<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: official_login.php'); exit; }

// Legacy route: keep old links working by redirecting to the dedicated pages.
$cat = $_GET['cat'] ?? 'Documents';
$cat = is_string($cat) ? $cat : 'Documents';

$map = [
    'Documents' => 'documents.php',
    'Reports'   => 'reports.php',
    'Projects'  => 'projects.php',
];

header('Location: ' . ($map[$cat] ?? 'documents.php'));
exit;
