<?php
// Shared Official sidebar navigation
if (!function_exists('app_nav_active')) {
    function app_nav_active($files) {
        $current = strtolower(basename($_SERVER['PHP_SELF'] ?? ''));
        foreach ((array)$files as $f) {
            if ($current === strtolower($f)) return 'active';
        }
        return '';
    }
}
?>

<div class="sidebar">
    <h4>SK FileHub</h4>
    <div class="sidebar-subtitle">Official</div>

    <a href="official_dashboard.php" class="<?= app_nav_active(['official_dashboard.php']) ?>"><i class="fa fa-home"></i> Dashboard</a>
    <a href="File_Management.php" class="<?= app_nav_active(['File_Management.php','share_file.php']) ?>"><i class="fa fa-folder"></i> File Management</a>
    <a href="File_status.php" class="<?= app_nav_active(['File_status.php']) ?>"><i class="fa fa-share-alt"></i> File Status</a>
    <a href="upload_file.php" class="<?= app_nav_active(['upload_file.php']) ?>"><i class="fa fa-upload"></i> Upload File</a>

    <hr>
    <div class="sidebar-section-title">File Category</div>
    <a href="documents.php" class="<?= app_nav_active(['documents.php']) ?>"><i class="fa fa-circle text-danger"></i> Documents</a>
    <a href="reports.php" class="<?= app_nav_active(['reports.php']) ?>"><i class="fa fa-circle text-primary"></i> Reports</a>
    <a href="projects.php" class="<?= app_nav_active(['projects.php']) ?>"><i class="fa fa-circle text-success"></i> Projects</a>

    <a href="logout.php" class="text-danger mt-3"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

