<?php
// Database configuration for SK Payatas File Management System

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // leave blank for default XAMPP setup
define('DB_NAME', 'skpayatas');

// Connect to MySQL using mysqli
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error);
}

// Ensure must_change_password column exists on users table (for first-login password change)
try {
    if ($result = $mysqli->query("SHOW COLUMNS FROM users LIKE 'must_change_password'")) {
        if ($result->num_rows === 0) {
            @$mysqli->query("ALTER TABLE users ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0 AFTER password");
        }
        $result->free();
    }
} catch (Throwable $e) {
    // If this fails, we just skip; app will still work without the flag.
}

// Ensure files table has new upload fields
try {
    $newCols = [
        'sub_category'   => 'VARCHAR(255) DEFAULT ""',
        'sequence'       => 'VARCHAR(100) DEFAULT ""',
        'subject'        => 'VARCHAR(255) DEFAULT ""',
        'doc_date'       => 'DATE DEFAULT NULL',
        'for_approval'   => 'TINYINT(1) NOT NULL DEFAULT 0',
        'admin_comment'  => 'TEXT NULL'
    ];
    foreach ($newCols as $col => $def) {
        $r = @$mysqli->query("SHOW COLUMNS FROM files LIKE '$col'");
        if ($r && $r->num_rows === 0) @$mysqli->query("ALTER TABLE files ADD COLUMN $col $def");
        if ($r) $r->free();
    }
} catch (Throwable $e) { /* skip */ }

// Ensure files table has seq_num for auto sequence (consistent, no gaps)
try {
    $r = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'seq_num'");
    if ($r && $r->num_rows === 0) {
        @$mysqli->query("ALTER TABLE files ADD COLUMN seq_num INT UNSIGNED NOT NULL DEFAULT 0 AFTER sequence");
    }
    if ($r) $r->free();
} catch (Throwable $e) { /* skip */ }

// Ensure files table has deleted_at for soft delete (Recently Deleted)
try {
    $r = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'deleted_at'");
    if ($r && $r->num_rows === 0) {
        @$mysqli->query("ALTER TABLE files ADD COLUMN deleted_at DATETIME DEFAULT NULL");
    }
    if ($r) $r->free();
} catch (Throwable $e) { /* skip */ }

// Ensure files table has status column for document approval tracking
try {
    $r = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'status'");
    if ($r && $r->num_rows === 0) {
        @$mysqli->query("ALTER TABLE files ADD COLUMN status VARCHAR(50) DEFAULT 'Pending'");
    }
    if ($r) $r->free();
} catch (Throwable $e) { /* skip */ }

// Simple helper to record activity log entries (best-effort)
if (!function_exists('log_activity')) {
    function log_activity(?int $fileId, string $action, ?int $userId = null): void {
        global $mysqli;
        if (!$mysqli instanceof mysqli) return;
        static $checked = false;
        static $hasTable = false;
        if (!$checked) {
            $res = @$mysqli->query("SHOW TABLES LIKE 'activity_log'");
            $hasTable = ($res && $res->num_rows > 0);
            if ($res) $res->free();
            $checked = true;
        }
        if (!$hasTable) return;
        // Use legacy structure: file_id, action, created_at
        $stmt = @$mysqli->prepare("INSERT INTO activity_log (file_id, action, created_at) VALUES (?, ?, NOW())");
        if (!$stmt) return;
        $fid = $fileId ?? 0;
        $stmt->bind_param("is", $fid, $action);
        @$stmt->execute();
        $stmt->close();
    }
}

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define constants for file paths
define('BASE_PATH', realpath(__DIR__ . '/../') . '/');
define('UPLOAD_DIR', BASE_PATH . 'uploads/');

// Ensure upload directory exists
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}
?>
