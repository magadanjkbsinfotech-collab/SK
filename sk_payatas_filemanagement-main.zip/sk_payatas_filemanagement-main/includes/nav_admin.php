<?php
// Shared Admin sidebar navigation
$__app_current = strtolower(basename($_SERVER['PHP_SELF'] ?? ''));
if (!function_exists('app_nav_active')) {
    function app_nav_active($files) {
        $current = strtolower(basename($_SERVER['PHP_SELF'] ?? ''));
        foreach ((array)$files as $f) {
            if ($current === strtolower($f)) return 'active';
        }
        return '';
    }
}
?>

<div class="sidebar">
    <h4>SK FileHub</h4>
    <div class="sidebar-subtitle">Admin</div>

    <a href="admin_dashboard.php" class="<?= app_nav_active(['admin_dashboard.php']) ?>">📊 Dashboard</a>
    <a href="Ad_File_Management.php" class="<?= app_nav_active(['Ad_File_Management.php']) ?>">📁 File Management</a>
    <a href="Ad_File_Status.php" class="<?= app_nav_active(['Ad_File_Status.php']) ?>">🔄 File Status</a>

    <hr>
    <div class="sidebar-section-title admin-tools-title">Admin Tools</div>
    <a href="user_management.php" class="nav-admin-tool <?= app_nav_active(['user_management.php','add_user.php']) ?>">👥 User Management</a>
    <a href="Activity_Logs.php" class="nav-admin-tool <?= app_nav_active(['Activity_Logs.php']) ?>">📝 Activity Logs</a>
    <a href="Ad_Storages.php" class="nav-admin-tool <?= app_nav_active(['Ad_Storages.php']) ?>">💾 Storage</a>

    <a href="logout.php" class="text-danger mt-3">🚪 Logout</a>
</div>

