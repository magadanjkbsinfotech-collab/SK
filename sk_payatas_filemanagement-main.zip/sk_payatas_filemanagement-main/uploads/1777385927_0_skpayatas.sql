-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2026 at 05:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skpayatas`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `official_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `official_id`, `action`, `file_id`, `created_at`) VALUES
(2, NULL, 'Uploaded file', 3, '2026-04-16 12:47:11'),
(3, NULL, 'Status set to Rejected', 3, '2026-04-16 12:48:03'),
(4, NULL, 'Status set to Rejected', 3, '2026-04-16 12:48:25'),
(5, NULL, 'Uploaded file', 4, '2026-04-16 13:37:36'),
(6, NULL, 'Status set to Approved', 4, '2026-04-23 05:09:46'),
(7, NULL, 'Status set to Pending', 2, '2026-04-23 05:52:50'),
(8, NULL, 'Uploaded file', 5, '2026-04-24 12:58:45'),
(9, NULL, 'Status set to Approved', 5, '2026-04-24 13:05:45'),
(10, NULL, 'Uploaded file', 6, '2026-04-24 13:18:46'),
(11, NULL, 'Status set to Reviewed', 6, '2026-04-24 13:19:34'),
(12, NULL, 'Status set to Rejected', 6, '2026-04-24 13:19:46'),
(13, NULL, 'Status set to Pending', 6, '2026-04-24 14:16:43');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `filepath` varchar(255) DEFAULT NULL,
  `filesize` bigint(20) DEFAULT 0,
  `uploaded_by` int(11) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_activity`
--

CREATE TABLE `document_activity` (
  `id` int(11) NOT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `tracking_code` varchar(50) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `size` bigint(20) DEFAULT 0,
  `uploaded_by` varchar(100) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'pending',
  `category` varchar(50) DEFAULT 'Documents',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `sub_category` varchar(255) DEFAULT '',
  `sequence` varchar(100) DEFAULT '',
  `seq_num` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `subject` varchar(255) DEFAULT '',
  `doc_date` date DEFAULT NULL,
  `for_approval` tinyint(1) NOT NULL DEFAULT 0,
  `admin_comment` text DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `tracking_code`, `filename`, `filepath`, `size`, `uploaded_by`, `uploaded_at`, `status`, `category`, `reviewed_by`, `reviewed_at`, `sub_category`, `sequence`, `seq_num`, `subject`, `doc_date`, `for_approval`, `admin_comment`, `deleted_at`) VALUES
(2, NULL, 'Potential_and_challenges_of_blockchain_technology_.pdf', 'uploads/1770106154_Potential_and_challenges_of_blockchain_technology_.pdf', 571662, '19', '2026-02-03 08:09:14', 'Pending', 'Reports', NULL, NULL, '', '', 0, '', NULL, 0, '', NULL),
(3, NULL, 'RobloxScreenShot20260320_232630654.png', 'uploads/1776343631_0_RobloxScreenShot20260320_232630654.png', 2661186, '19', '2026-04-16 12:47:11', 'Rejected', 'roblox', NULL, NULL, 'piece', '1', 1, '', '2026-04-16', 0, 'bolok yan', NULL),
(4, NULL, 'ScreenShot30.bmp', 'uploads/1776346656_0_ScreenShot30.bmp', 2764854, '19', '2026-04-16 13:37:36', 'Approved', 'fallout new vegas', NULL, NULL, 'fallout', '2', 2, '', '2026-04-16', 1, '', NULL),
(5, 'DOC-FOR-20260424-8117', 'Screenshot 2026-03-23 214638.png', 'uploads/1777035525_0_Screenshot 2026-03-23 214638.png', 403403, '19', '2026-04-24 12:58:45', 'Approved', 'Documents', NULL, NULL, 'Forms & Templates', '3', 3, '', '2026-04-24', 1, 'ok', NULL),
(6, 'RPT-MIN-20260424-4245', 'WIN_20260323_16_26_36_Pro.jpg', 'uploads/1777036726_0_WIN_20260323_16_26_36_Pro.jpg', 179372, '19', '2026-04-24 13:18:46', 'Pending', 'Reports', NULL, NULL, 'Minutes Of Meetings (MOM)', '4', 4, 'Basketball', '2026-04-24', 0, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `officials`
--

CREATE TABLE `officials` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `profile_img` varchar(255) DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `theme_color` varchar(50) DEFAULT '#007bff',
  `site_logo` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `theme_color`, `site_logo`, `updated_at`) VALUES
(1, 'SK FileHub', '#000000', 'enabled', '2025-10-19 03:26:09');

-- --------------------------------------------------------

--
-- Table structure for table `shared_files`
--

CREATE TABLE `shared_files` (
  `id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL,
  `shared_by` int(11) NOT NULL,
  `shared_to` int(11) NOT NULL,
  `shared_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `fullname` varchar(150) DEFAULT NULL,
  `role` enum('admin','official') DEFAULT 'official',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `must_change_password`, `fullname`, `role`, `created_at`) VALUES
(16, 'admin1', '$2y$10$07BhW8zDhaXqQTW8PjwlrO7xxUOzah/skhLQUx5KerkhwXHUeefFC', 0, 'Khem1', 'admin', '2025-10-14 16:06:04'),
(17, 'Kagawad1', '$2y$10$A/XDT/Rekinmnsb6qn11IeWKd/4z2qeaNxTFM72muBABbFj2DtMmK', 0, 'Sam', 'official', '2025-10-19 03:28:03'),
(19, 'jhon', '$2y$10$YVGiKTDQ3qn4TwcRvwjmvOYQ1.vE.mOX1yYE4j3DLmVtLPovIKE6q', 0, 'Jhon kien M. Magadan', 'official', '2026-01-28 10:29:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `official_id` (`official_id`),
  ADD KEY `file_id` (`file_id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_activity`
--
ALTER TABLE `document_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doc_id` (`doc_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tracking_code` (`tracking_code`);

--
-- Indexes for table `officials`
--
ALTER TABLE `officials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shared_files`
--
ALTER TABLE `shared_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `file_id` (`file_id`),
  ADD KEY `shared_by` (`shared_by`),
  ADD KEY `shared_to` (`shared_to`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_activity`
--
ALTER TABLE `document_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `officials`
--
ALTER TABLE `officials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shared_files`
--
ALTER TABLE `shared_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`official_id`) REFERENCES `officials` (`id`),
  ADD CONSTRAINT `activity_log_ibfk_2` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`);

--
-- Constraints for table `document_activity`
--
ALTER TABLE `document_activity`
  ADD CONSTRAINT `document_activity_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shared_files`
--
ALTER TABLE `shared_files`
  ADD CONSTRAINT `shared_files_ibfk_1` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `shared_files_ibfk_2` FOREIGN KEY (`shared_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `shared_files_ibfk_3` FOREIGN KEY (`shared_to`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
