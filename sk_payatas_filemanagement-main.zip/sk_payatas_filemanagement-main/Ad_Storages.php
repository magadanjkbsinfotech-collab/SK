<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (strtolower($_SESSION['role']) !== 'admin') { header('Location: official_dashboard.php'); exit; }

function fmt_bytes($bytes) {
    $bytes = (float)$bytes;
    $units = ['B','KB','MB','GB','TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units)-1) { $bytes /= 1024; $i++; }
    return round($bytes, 2) . ' ' . $units[$i];
}

// Category counts
$hasDeletedAt = false;
$chk = @$mysqli->query("SHOW COLUMNS FROM files LIKE 'deleted_at'");
if ($chk && $chk->num_rows > 0) { $hasDeletedAt = true; $chk->free(); }
$delClause = $hasDeletedAt ? " AND deleted_at IS NULL" : "";
$docCount = (int)(@$mysqli->query("SELECT COUNT(*) AS c FROM files WHERE category='Documents'" . $delClause)->fetch_assoc()['c'] ?? 0);
$projCount = (int)(@$mysqli->query("SELECT COUNT(*) AS c FROM files WHERE category='Projects'" . $delClause)->fetch_assoc()['c'] ?? 0);
$repCount = (int)(@$mysqli->query("SELECT COUNT(*) AS c FROM files WHERE category='Reports'" . $delClause)->fetch_assoc()['c'] ?? 0);
$totalCount = $docCount + $projCount + $repCount;
if ($totalCount === 0) $totalCount = 1; // avoid division by zero

// Storage usage
$totalBytes = (int)(@$mysqli->query("SELECT COALESCE(SUM(size),0) AS total FROM files" . ($hasDeletedAt ? " WHERE deleted_at IS NULL" : ""))->fetch_assoc()['total'] ?? 0);
$totalGB = round($totalBytes / (1024*1024*1024), 2);
$totalSpaceGB = 364; // as in photo
$availableGB = max(0, $totalSpaceGB - $totalGB);
$usedPercent = min(100, round(($totalGB / $totalSpaceGB) * 100));

// Recently deleted (soft-deleted files)
$recentlyDeleted = false;
if ($hasDeletedAt) {
    $recentlyDeleted = @$mysqli->query("
        SELECT f.id, f.filename, f.category, f.deleted_at, u.fullname, u.username
        FROM files f
        LEFT JOIN users u ON f.uploaded_by = u.id
        WHERE f.deleted_at IS NOT NULL
        ORDER BY f.deleted_at DESC
        LIMIT 10
    ");
}

// Recent backups from backups/ folder
$backupsDir = BASE_PATH . 'backups/';
$recentBackups = [];
if (is_dir($backupsDir)) {
    $files = glob($backupsDir . '*.zip');
    if ($files) {
        usort($files, fn($a,$b) => filemtime($b) - filemtime($a));
        foreach (array_slice($files, 0, 5) as $f) {
            $recentBackups[] = [
                'name' => basename($f),
                'time' => filemtime($f),
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Storage | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body { background-image: url('SK.png'); background-repeat: no-repeat; background-size: cover; background-attachment: fixed; }
.storage-search-bar { display: flex; align-items: center; gap: 0.5rem; background: #fff; border-radius: 12px; padding: 0.5rem 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); max-width: 320px; }
.storage-search-bar input { border: none; flex: 1; }
.storage-search-bar input:focus { box-shadow: none; outline: none; }
.storage-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); padding: 1.25rem; position: relative; }
.storage-card .cat-icon { color: #a902ca; font-size: 1.25rem; }
.storage-card .cat-count { font-weight: 700; font-size: 1.1rem; }
.storage-card .progress { height: 6px; background: #e9ecef; }
.storage-card .progress-bar { background: #a902ca; }
.gauge-circle { width: 180px; height: 180px; border-radius: 50%; background: conic-gradient(#a902ca 0deg calc(var(--pct, 0) * 3.6deg), #e9ecef calc(var(--pct, 0) * 3.6deg) 360deg); }
.backup-toggle .form-check-input:checked { background-color: #10b981; border-color: #10b981; }
.btn-manual-backup { background: #0d6efd; border-color: #0d6efd; color: #fff; }
.btn-manual-backup:hover { background: #0b5ed7; border-color: #0a58ca; color: #fff; }
.recent-backup-item { padding: 0.5rem 0; border-bottom: 1px solid #eee; font-size: 0.9rem; }
.recent-backup-item:last-child { border-bottom: none; }
.text-success-status { color: #10b981; }
</style>
</head>
<body>
<?php include 'includes/nav_admin.php'; ?>

<div class="main">
    <div class="fm-page">
        <div class="fm-topbar mb-3 d-flex justify-content-between align-items-center flex-wrap gap-3">
            <h4 class="mb-0 fw-semibold">Storage</h4>
            <div class="storage-search-bar">
                <i class="fa fa-search text-muted"></i>
                <input type="search" class="form-control" placeholder="Search">
                <i class="fa fa-sliders text-muted" style="cursor:pointer" title="Filters"></i>
            </div>
        </div>

        <?php if (isset($_GET['ok'])): ?>
            <div class="alert alert-success">
                <?php if ($_GET['ok'] === 'backup_clear'): ?>
                    Backup created and storage cleared. Deleted files: <?= (int)($_GET['n'] ?? 0) ?>.
                    <?php if (!empty($_GET['file'])): ?>
                        <a class="ms-2" href="download_backup.php?file=<?= urlencode($_GET['file']) ?>">Download backup</a>
                    <?php endif; ?>
                <?php elseif ($_GET['ok'] === 'cleared'): ?>
                    Storage cleared. Deleted files: <?= (int)($_GET['n'] ?? 0) ?>.
                <?php endif; ?>
            </div>
        <?php elseif (isset($_GET['err'])): ?>
            <div class="alert alert-danger">Action failed (<?= htmlspecialchars($_GET['err']) ?>).</div>
        <?php endif; ?>

        <div class="row g-3">
            <!-- Left: Category cards + Recently Deleted -->
            <div class="col-lg-8">
                <div class="row g-3 mb-3">
                    <div class="col-6 col-md-3">
                        <div class="storage-card">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <i class="fa fa-file-lines cat-icon"></i>
                                <i class="fa fa-ellipsis-v text-muted" style="cursor:pointer" title="More"></i>
                            </div>
                            <div class="cat-count"><?= number_format($docCount) ?> Files</div>
                            <div class="small text-muted">Documents</div>
                            <div class="progress mt-2">
                                <div class="progress-bar" style="width: <?= $totalCount ? round(($docCount/$totalCount)*100) : 0 ?>%"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="storage-card">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <i class="fa fa-folder-open cat-icon"></i>
                                <i class="fa fa-ellipsis-v text-muted" style="cursor:pointer" title="More"></i>
                            </div>
                            <div class="cat-count"><?= number_format($projCount) ?> Files</div>
                            <div class="small text-muted">Projects</div>
                            <div class="progress mt-2">
                                <div class="progress-bar" style="width: <?= $totalCount ? round(($projCount/$totalCount)*100) : 0 ?>%"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="storage-card">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <i class="fa fa-file-alt cat-icon"></i>
                                <i class="fa fa-ellipsis-v text-muted" style="cursor:pointer" title="More"></i>
                            </div>
                            <div class="cat-count"><?= number_format($repCount) ?> Files</div>
                            <div class="small text-muted">Reports</div>
                            <div class="progress mt-2">
                                <div class="progress-bar" style="width: <?= $totalCount ? round(($repCount/$totalCount)*100) : 0 ?>%"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="storage-card">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <i class="fa fa-database cat-icon"></i>
                                <i class="fa fa-ellipsis-v text-muted" style="cursor:pointer" title="More"></i>
                            </div>
                            <div class="cat-count"><?= number_format($docCount + $projCount + $repCount) ?> Files</div>
                            <div class="small text-muted">Total Files</div>
                            <div class="progress mt-2">
                                <div class="progress-bar" style="width: 100%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="storage-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="mb-0 fw-semibold">RECENTLY DELETED</h6>
                        <a href="#" class="text-primary small text-decoration-none">View all &gt;</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Date</th>
                                    <th>Uploaded by</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($recentlyDeleted && $recentlyDeleted->num_rows > 0): ?>
                                    <?php while ($row = $recentlyDeleted->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['filename']) ?></td>
                                            <td><?= htmlspecialchars($row['category'] ?? '-') ?></td>
                                            <td><?= !empty($row['deleted_at']) ? date("m.d.Y", strtotime($row['deleted_at'])) : '-' ?></td>
                                            <td><?= htmlspecialchars($row['fullname'] ?? $row['username'] ?? '-') ?></td>
                                            <td><i class="fa fa-chevron-right text-muted small"></i></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center text-muted py-3">No recently deleted files.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Right: Storage gauge + Backup & Recovery -->
            <div class="col-lg-4">
                <div class="storage-card mb-3 text-center">
                    <h6 class="mb-3 fw-semibold">Storage</h6>
                    <div class="d-flex justify-content-center mb-3">
                        <div class="gauge-circle" style="--pct: <?= $usedPercent ?>"></div>
                    </div>
                    <p class="mb-1 small">Used: <?= $totalGB ?> GB</p>
                    <p class="mb-1 small text-success">Available: <?= $availableGB ?> GB</p>
                    <p class="mb-0 small text-muted">Total Space: <?= $totalSpaceGB ?> GB</p>
                </div>

                <div class="storage-card mb-3">
                    <h6 class="mb-3 fw-semibold">Backup & Recovery</h6>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="fw-semibold small">Auto Backup</div>
                                <div class="small text-muted">Next backup in 6 hours</div>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input backup-toggle" type="checkbox" id="autoBackup" checked>
                                <label class="form-check-label small" for="autoBackup">Active</label>
                            </div>
                        </div>
                    </div>
                    <form action="backup_recovery.php" method="post" class="mb-2">
                        <button type="submit" name="backup" class="btn btn-manual-backup w-100">
                            <i class="fa fa-cloud-upload-alt me-1"></i> Manual Backup
                        </button>
                    </form>
                    <a href="#" class="small text-primary text-decoration-none d-inline-flex align-items-center gap-1">
                        <i class="fa fa-sync-alt"></i> Recovery Options
                    </a>
                </div>

                <div class="storage-card">
                    <h6 class="mb-3 fw-semibold">Recent Backups</h6>
                    <?php if (count($recentBackups) > 0): ?>
                        <?php foreach ($recentBackups as $b): ?>
                            <div class="recent-backup-item d-flex justify-content-between align-items-center">
                                <span class="small"><?= date("M j, g:i A", $b['time']) ?></span>
                                <span class="text-success-status small fw-semibold">Success</span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="small text-muted mb-0">No backups yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
