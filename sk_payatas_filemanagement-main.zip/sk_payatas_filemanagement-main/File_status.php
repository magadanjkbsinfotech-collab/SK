<?php
require 'includes/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: official_login.php'); exit; }
if (strtolower($_SESSION['role'] ?? '') !== 'official') { header('Location: admin_dashboard.php'); exit; }

$user_id = (int)$_SESSION['user_id'];

// Show BOTH:
// 1) Files uploaded by this official
// 2) Files shared to this official
// (Shared files are optional; if shared_files table doesn't exist, we still show uploads.)

$hasShared = false;
$t = @$mysqli->query("SHOW TABLES LIKE 'shared_files'");
if ($t && $t->num_rows > 0) $hasShared = true;
if ($t) $t->free();

$search = trim($_GET['q'] ?? '');
$statusTab = strtolower(trim($_GET['status'] ?? 'all'));
if ($statusTab === '' || $statusTab === 'all') {
    $statusTab = 'all';
}
if ($statusTab === 'archive') {
    $statusTab = 'archived';
}

$tabOrder = ['all', 'pending', 'reviewed', 'approved', 'rejected', 'archived'];
$tabLabels = [
    'all' => 'All',
    'pending' => 'Pending',
    'reviewed' => 'Reviewed',
    'approved' => 'Approved',
    'rejected' => 'Rejected',
    'archived' => 'Archive',
];
if (!in_array($statusTab, $tabOrder, true)) {
    $statusTab = 'all';
}

$tabCounts = array_fill_keys($tabOrder, 0);
$countSql = '';
if ($hasShared) {
    $countSql = "SELECT LOWER(TRIM(COALESCE(f.status, ''))) AS status, COUNT(DISTINCT f.id) AS c
                 FROM files f
                 LEFT JOIN shared_files s ON s.file_id = f.id AND s.shared_to = ?
                 WHERE (f.uploaded_by = ? OR s.shared_to = ?) AND f.deleted_at IS NULL
                 GROUP BY LOWER(TRIM(COALESCE(f.status, '')))";
    $stmtCount = $mysqli->prepare($countSql);
    if ($stmtCount) {
        $stmtCount->bind_param('iii', $user_id, $user_id, $user_id);
        $stmtCount->execute();
        $cntResult = $stmtCount->get_result();
    }
} else {
    $countSql = "SELECT LOWER(TRIM(COALESCE(status, ''))) AS status, COUNT(*) AS c
                 FROM files
                 WHERE uploaded_by = ? AND deleted_at IS NULL
                 GROUP BY LOWER(TRIM(COALESCE(status, '')))";
    $stmtCount = $mysqli->prepare($countSql);
    if ($stmtCount) {
        $stmtCount->bind_param('i', $user_id);
        $stmtCount->execute();
        $cntResult = $stmtCount->get_result();
    }
}

if (!empty($cntResult)) {
    while ($row = $cntResult->fetch_assoc()) {
        $statusLabel = strtolower(trim($row['status'] ?? ''));
        if ($statusLabel === '') {
            $statusLabel = 'pending';
        }
        $count = (int)($row['c'] ?? 0);
        if (in_array($statusLabel, ['pending', 'reviewed', 'approved', 'rejected', 'archived'], true)) {
            $tabCounts[$statusLabel] += $count;
        } else {
            $tabCounts['pending'] += $count;
        }
        $tabCounts['all'] += $count;
    }
    $cntResult->free();
}

$where = [];
$params = [];
$types = '';
$join = '';
$orderBy = 'f.uploaded_at DESC';

if ($hasShared) {
    $join = "LEFT JOIN shared_files s ON s.file_id = f.id AND s.shared_to = ?
             LEFT JOIN users u_share ON s.shared_by = u_share.id
             LEFT JOIN users u_uploader ON f.uploaded_by = u_uploader.id";
    $where[] = '(f.uploaded_by = ? OR s.shared_to = ?)';
    $where[] = 'f.deleted_at IS NULL';
    $params = [$user_id, $user_id, $user_id];
    $types = 'iii';
    $orderBy = 'COALESCE(s.shared_at, f.uploaded_at) DESC';
} else {
    $join = "LEFT JOIN users u_uploader ON f.uploaded_by = u_uploader.id";
    $where[] = 'f.uploaded_by = ?';
    $where[] = 'f.deleted_at IS NULL';
    $params = [$user_id];
    $types = 'i';
}

if ($statusTab === 'pending') {
    $where[] = "(f.status IS NULL OR TRIM(COALESCE(f.status, '')) = '' OR LOWER(TRIM(f.status)) = 'pending')";
} elseif (in_array($statusTab, ['reviewed', 'approved', 'rejected', 'archived'], true)) {
    $where[] = 'LOWER(TRIM(f.status)) = ?';
    $params[] = $statusTab;
    $types .= 's';
}

if ($search !== '') {
    $where[] = "(f.filename LIKE CONCAT('%',?,'%') OR COALESCE(u_share.fullname, '') LIKE CONCAT('%',?,'%') OR COALESCE(u_share.username, '') LIKE CONCAT('%',?,'%'))";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= 'sss';
}

$sql = "SELECT f.*, COALESCE(u_share.fullname, u_share.username, '') AS shared_by_name, COALESCE(u_uploader.fullname, u_uploader.username, '') AS uploader_name
        FROM files f
        $join";
if (count($where) > 0) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= " ORDER BY $orderBy LIMIT 300";

$files = null;
$stmt = $mysqli->prepare($sql);
if ($stmt) {
    if (count($params) > 0) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $files = $stmt->get_result();
}
$result = $files;
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>File Status | SK FileHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body {
     background-image: url('SK.png');
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
}
.card-box{background:#fff;border-radius:12px;padding:25px;box-shadow:0 4px 12px rgba(0,0,0,0.05);}
.file-item{display:flex;justify-content:space-between;align-items:center;padding:10px;border-bottom:1px solid #eee;}
.fs-list { display: block; width: 100%; overflow-x: hidden; }
.fs-row { display: grid; grid-template-columns: 60px 1fr 1fr 1fr 1fr 100px; gap: 1rem; align-items: center; padding: 0.75rem; border-bottom: 1px solid #e9ecef; font-size: 0.9rem; width: 100%; }
.fs-row.fs-head { background: #f8f9fa; font-weight: 600; position: sticky; top: 0; z-index: 10; }
.fs-row div { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.fs-file-info { display: flex; flex-direction: column; gap: 0.25rem; }
.fs-file-name { font-weight: 500; }
.fs-tracking-code { font-size: 0.85rem; color: #0d6efd; }
</style>
</head>
<body>
<?php include 'includes/nav_official.php'; ?>
<div class="main">
    <div class="fm-page">
        <div class="row g-3">
            <div class="col-12">
                <div class="fm-topbar mb-3 d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">
                    <div>
                        <h4 class="mb-1 fw-semibold">File Status</h4>
                        <p class="text-muted mb-0">View the current status of your uploaded and shared files.</p>
                    </div>
                    <form class="d-flex gap-2 align-items-center flex-wrap" method="get" action="File_status.php">
                        <div class="fm-search" style="min-width:220px;">
                            <input type="search" name="q" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Search file or uploader">
                        </div>
                        <?php if ($statusTab !== 'all'): ?>
                            <input type="hidden" name="status" value="<?= htmlspecialchars($statusTab) ?>">
                        <?php endif; ?>
                        <button type="submit" class="btn btn-light border">Search</button>
                    </form>
                </div>

                <ul class="nav fs-status-tabs mb-3 list-unstyled">
                    <?php foreach ($tabOrder as $tab): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= $statusTab === $tab ? 'active' : '' ?>"
                               href="<?= htmlspecialchars('File_status.php' . ($tab === 'all' ? ($search !== '' ? '?q=' . urlencode($search) : '') : '?status=' . urlencode($tab) . ($search !== '' ? '&q=' . urlencode($search) : ''))) ?>">
                                <?= htmlspecialchars($tabLabels[$tab]) ?>
                                <span class="fs-tab-count"><?= (int)($tabCounts[$tab] ?? 0) ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <div class="fs-list">
                    <div class="fs-row fs-head">
                        <div></div>
                        <div>File Name</div>
                        <div>Date Uploaded</div>
                        <div>Status</div>
                        <div>Uploader</div>
                        <div class="text-end">Action</div>
                    </div>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while ($file = $result->fetch_assoc()): ?>
                            <?php
                                $st = strtolower(trim($file['status'] ?? ''));
                                if ($st === '') {
                                    $st = 'pending';
                                }
                                $pillClass = in_array($st, ['pending', 'approved', 'rejected', 'reviewed', 'archived'], true) ? $st : 'archived';
                            ?>
                            <div class="fs-row">
                                <div>
                                    <i class="fa fa-file text-primary"></i>
                                </div>
                                <div class="fs-file-info">
                                    <div class="fs-file-name"><?= htmlspecialchars($file['filename']) ?></div>
                                    <div class="fs-tracking-code"><?= htmlspecialchars($file['tracking_code'] ?? '-') ?></div>
                                </div>
                                <div class="text-muted"><?= !empty($file['uploaded_at']) ? date('Y-m-d', strtotime($file['uploaded_at'])) : '-' ?></div>
                                <div>
                                    <span class="fs-pill <?= $pillClass ?>">
                                        <span class="fs-dot"></span>
                                        <?= htmlspecialchars(ucfirst($st)) ?>
                                    </span>
                                </div>
                                <div class="text-muted small">
                                    <?= htmlspecialchars($file['uploader_name'] ?? '-') ?>
                                </div>
                                <div class="text-end">
                                    <a href="<?= htmlspecialchars($file['filepath']) ?>" class="btn btn-sm btn-outline-primary">View</a>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="p-4 text-center text-muted">No files found.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
